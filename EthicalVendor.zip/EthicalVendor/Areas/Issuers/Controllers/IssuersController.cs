﻿using EthicalVendor.Areas.Borrower.Models;
using EthicalVendor.Models;
using EthicalVendor.Models.ViewModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace EthicalVendor.Areas.Issuers.Controllers
{
    [Area("Issuers")]
    public class IssuersController : Controller
    {
        private IConfiguration _configuration;
        private readonly string token;

        public IssuersController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public IActionResult Home()
        {
            //Investor Can only work on confirm list
            return View();
        }


        public IActionResult ConfirmedList()
        {
            //Issuer to view confirmed list
            return View();
        }
        public IActionResult GenInvoiceList()
        {
            //Issuer to view confirmed list
            return View();
        }
        [HttpGet]
        public async Task<JsonResult> LPOlistData()
        {
            //LPOList paytermlist = new LPOList();
            using (var httpClient = new HttpClient())
            {
                IHttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
                var userID = _httpContextAccessor.HttpContext.Session.GetString("UserID");
                var j = Convert.ToInt32(userID);
                var userid = j.ToString();
                
                string nkey = GetIPAddress();
                var datacol = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "ISSUER_ID", userid },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);
                var lpoorderbyissuer = _configuration["lpoorderbyissuer"];
                using (var response = await httpClient.PostAsync(lpoorderbyissuer, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<LPOList>(apiResponse);
                   
                    List<LPO> taiwo = new List<LPO>();
                    foreach (var obj in paytermlist.LPOs)
                    {
                        LPO lpo = new LPO();
                        lpo.country = obj.country;
                        lpo.BORROWER_COST = Convert.ToDecimal(obj.BORROWER_COST).ToString("N");
                        lpo.LPO_NUMBER = obj.LPO_NUMBER;
                        lpo.VAL_OF_PO = Convert.ToDecimal(obj.VAL_OF_PO).ToString("N");
                        lpo.LPO_TOTAL_PRICE = obj.LPO_TOTAL_PRICE;
                        lpo.LPO_ITEM_DESCRIPTION = obj.LPO_ITEM_DESCRIPTION;
                        lpo.LPO_ORDER_ID = obj.LPO_ORDER_ID;
                        lpo.INITIAL_INVESTMENT_BY_BORROWER = obj.INITIAL_INVESTMENT_BY_BORROWER;
                        lpo.INVESTED_FUND_SOFAR = obj.INVESTED_FUND_SOFAR;
                        taiwo.Add(lpo);

                    }
                    return Json(new { data = taiwo.ToArray() });

                }

            }

        }

        //To View Confired List
        [HttpGet]
        public async Task<JsonResult> ConfirmedLPOlistData()
        {
            //To Get List of Confirmed LPO BY Issuer
            using (var httpClient = new HttpClient())
            {
                IHttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
                var userID = _httpContextAccessor.HttpContext.Session.GetString("UserID");
                var j = Convert.ToInt32(userID);
                var userid = j.ToString();
                
                string nkey = GetIPAddress();
                var datacol = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "ISSUER_ID", userid },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);

                var listconfirmlpoorderbyissuer = _configuration["listconfirmlpoorderbyissuer"];
                using (var response = await httpClient.PostAsync(listconfirmlpoorderbyissuer, content))
                {

                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<LPOList>(apiResponse);
                    //var convertedJson = JsonConvert.SerializeObject(paytermlist);

                    List<LPO> taiwo = new List<LPO>();
                    if (paytermlist.LPOs == null)
                    {
                        LPO lpo = new LPO();
                        lpo.BORROWER_COST = "No Record";
                        lpo.LPO_NUMBER = "No Record";
                        lpo.VAL_OF_PO = "No Record";
                        lpo.LPO_TOTAL_PRICE = "No Record";
                        lpo.ISSUER_CONFIRMATION_REMARKS = "No Record";
                        lpo.LPO_ORDER_ID = "No Record";
                        lpo.INITIAL_INVESTMENT_BY_BORROWER = "No Record";
                        lpo.INVESTED_FUND_SOFAR = "No Record";
                        taiwo.Add(lpo);
                        return Json(new { data = taiwo.ToArray() });

                    }
                    foreach (var obj in paytermlist.LPOs)
                    {
                        LPO lpo = new LPO();
                        lpo.country = obj.country;
                        lpo.BORROWER_COST = Convert.ToDecimal(obj.BORROWER_COST).ToString("N");
                        lpo.LPO_NUMBER = obj.LPO_NUMBER;
                        lpo.VAL_OF_PO = Convert.ToDecimal(obj.VAL_OF_PO).ToString("N");
                        //lpo.LPO_TOTAL_PRICE = obj.LPO_TOTAL_PRICE;
                        lpo.ISSUER_CONFIRMATION_REMARKS = obj.ISSUER_CONFIRMATION_REMARKS;
                        lpo.LPO_ORDER_ID = obj.LPO_ORDER_ID;
                        lpo.INITIAL_INVESTMENT_BY_BORROWER = obj.INITIAL_INVESTMENT_BY_BORROWER;
                        lpo.INVESTED_FUND_SOFAR = obj.INVESTED_FUND_SOFAR;
                        taiwo.Add(lpo);

                    }
                    return Json(new { data = taiwo.ToArray() });

                }

            }

        }

        [HttpGet]
        public async Task<IActionResult> ConfirmLPO(string id)
        {
           
            string nkey = GetIPAddress();
            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "LPO_NUMBER", id },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);
                 var getlpoorder = _configuration["getlpoorder"];
                using (var response = await httpClient.PostAsync(getlpoorder, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<IssuerVM>(apiResponse);

                    return View(paytermlist);
                }

            }
        }

        [HttpGet]
        public async Task<IActionResult> ConfirmedDetails(string id)
        {
            
            string nkey = GetIPAddress();
            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "LPO_NUMBER", id },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);
                var getlpoorder = _configuration["getlpoorder"];
                using (var response = await httpClient.PostAsync(getlpoorder, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<IssuerVM>(apiResponse);

                    return View(paytermlist);
                }

            }
        }

        [HttpGet]
        public async Task<IActionResult> AcknowledgeForm(string id)
        {
            
            string nkey = GetIPAddress();
            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "LPO_NUMBER", id },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);
                var getlpoorder = _configuration["getlpoorder"];
                using (var response = await httpClient.PostAsync(getlpoorder, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<IssuerVM>(apiResponse);
                    return View(paytermlist);


                    /* _INVESTOR investor = new _INVESTOR();                 
                     investor.Remark = "";
                     IssueInvestorVM issueInvestor = new IssueInvestorVM();
                     issueInvestor.IssuerVM = paytermlist;
                     issueInvestor.INVESTOR = investor;
                     return View(issueInvestor);
                    */
                }

            }
        }

        [HttpGet]
        public async Task<JsonResult> ListOfInvoiceGenData()
        {
            
            string nkey = GetIPAddress();
            //LPOList paytermlist = new LPOList();
            using (var httpClient = new HttpClient())
            {
                IHttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
                var userID = _httpContextAccessor.HttpContext.Session.GetString("UserID");
                var j = Convert.ToInt32(userID);
                var userid = j.ToString();
                var datacol = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "ISSUER_ID", userid },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);
                var listconfirmlpoorderbyissuer = _configuration["listconfirmlpoorderbyissuer"];
                using (var response = await httpClient.PostAsync(listconfirmlpoorderbyissuer, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<LPOList>(apiResponse);


                    List<LPO> taiwo = new List<LPO>();
                    if (paytermlist.LPOs == null)
                    {
                        LPO lpo = new LPO();
                        lpo.BORROWER_COST = "No Record";
                        lpo.LPO_NUMBER = "No Record";
                        lpo.VAL_OF_PO = "No Record";
                        lpo.LPO_TOTAL_PRICE = "No Record";
                        lpo.ISSUER_CONFIRMATION_REMARKS = "No Record";
                        lpo.LPO_ORDER_ID = "No Record";
                        taiwo.Add(lpo);
                        return Json(new { data = taiwo.ToArray() });

                    }
                    foreach (var obj in paytermlist.LPOs)
                    {
                        LPO lpo = new LPO();
                        lpo.country = obj.country;
                        lpo.BORROWER_COST = obj.BORROWER_COST;
                        lpo.LPO_NUMBER = obj.LPO_NUMBER;
                        lpo.VAL_OF_PO = obj.VAL_OF_PO;
                        lpo.ISSUER_CONFIRMATION_REMARKS = obj.ISSUER_CONFIRMATION_REMARKS;
                        lpo.LPO_ORDER_ID = obj.LPO_ORDER_ID;
                        taiwo.Add(lpo);

                    }
                    return Json(new { data = taiwo.ToArray() });

                }

            }

        }
        [HttpPost]
        public async Task<IActionResult> IssuerConfirmation(IssuerVM issuerview, string Submit)
        {
            string IssuerConfirmation = Request.Form["IssuerConfirmation"];
            string ConfirmRemark = Request.Form["ConfirmRemark"];
            string LpoNumber = Request.Form["LpoNumber"];

            //string IssuerConfirmation = Request.Form["LPO.ORDER.ISSUER_CONFIRMATION"];
            //string ConfirmRemark = Request.Form["LPO.ORDER.ISSUER_CONFIRMATION_REMARKS"];
            //string LpoNumber = Request.Form["LPO.ORDER.LPO_NUMBER"];


            string nkey = GetIPAddress();

            IHttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
            var userID = _httpContextAccessor.HttpContext.Session.GetString("UserID");
            var j = Convert.ToInt32(userID);
            var userid = j.ToString();

            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "LPO_ISSUER_ID", userid},
                   { "LPO_NUMBER", LpoNumber },
                   { "ISSUER_CONFIRMATION", IssuerConfirmation },
                   { "ISSUER_CONFIRMATION_REMARKS", ConfirmRemark },
                   { "NKEY", nkey },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);
                 var confirmlpoorder = _configuration["confirmlpoorder"];
                using (var response = await httpClient.PostAsync(confirmlpoorder, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<IssuerVM>(apiResponse);
                    string message = "";
                    if (paytermlist.ERROR.errorcode == "0")
                    {
                        TempData["Message"] = "Your record has been Saved Successfully ";
                        message = "Your record has been Saved Successfully ";
                    }
                    else
                    {
                        TempData["Message"] = paytermlist.ERROR.errordescription;
                        message = paytermlist.ERROR.errordescription;
                    }
                    return Json(new { redirectToUrl = Url.Action("ConfirmedResult", "Issuers"), message });
                    //return RedirectToAction(nameof(Home));
                    //  http://localhost:5000/Issuers/Issuers/ConfirmedResult?ERROR=EthicalVendor.Models.ViewModels._ERROR
                }

            }


        }

        //[HttpPost]
        public IActionResult ConfirmedResult()
        {
            //if (issuervm.ERROR.errorcode == "0")
            //{
            //    TempData["Message"] = "Your record has been Saved Successfully ";
            //}
            //else
            //{
            //    TempData["Message"] = issuervm.ERROR.errordescription;
            //}
            return RedirectToAction(nameof(Home));
        }

        /* [HttpPost]
         public async Task<IActionResult> IssuerConfirmation(IssuerVM issuerview, string Submit)
         {

             if (Submit == "Save")
             {
             using (var httpClient = new HttpClient())
             {
                 var datacol = new Dictionary<string, string>
                 {
                    { "LPO_ISSUER_ID", issuerview.LPO.ISSUER.LPO_ISSUER_ID },
                    { "LPO_NUMBER", issuerview.LPO.ORDER.LPO_NUMBER },
                    { "ISSUER_CONFIRMATION", issuerview.LPO.ORDER.ISSUER_CONFIRMATION },
                    { "ISSUER_CONFIRMATION_REMARKS", issuerview.LPO.ORDER.ISSUER_CONFIRMATION_REMARKS },
                    { "NKEY", "AAAAAAA" },
                    { "CHANNEL", "W" },
                 };
                 var content = new FormUrlEncodedContent(datacol);

                 using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/EthSol_Confirm_LPO_ORDER", content))
                 {
                     string apiResponse = await response.Content.ReadAsStringAsync();
                     var paytermlist = JsonConvert.DeserializeObject<IssuerVM>(apiResponse);

                     if (paytermlist.ERROR.errorcode == "0")
                     {
                         TempData["Message"] = "Your record has been Saved Successfully ";
                     }
                     else
                     {
                         TempData["Message"] = paytermlist.ERROR.errordescription;
                     }

                     return RedirectToAction(nameof(Home));
                     //return View(paytermlist);
                 }

             }
              }
             else
             {
                 //your "Cancel" button code here..
                 return RedirectToAction(nameof(Home));
             }


         }*/

        [HttpPost]
        public async Task<IActionResult> IssuerAcknowledge(IssuerVM issuerview, string Submit)
        {
            
            string nkey = GetIPAddress();

            if (Submit == "Cancel")
            {
                return RedirectToAction(nameof(GenInvoiceList));
            }
            else
            {
                string issuerid = Request.Form["issuerid"];
                string lponumber = Request.Form["lponumber"];
                string remark = Request.Form["remark"];
                string yesno = Request.Form["yesno"];

                using (var httpClient = new HttpClient())
                {
                    //var datacol = new Dictionary<string, string>
                    //{
                    //   { "LPO_ISSUER_ID", issuerview.LPO.ISSUER.LPO_ISSUER_ID },
                    //   { "LPO_NUMBER", issuerview.LPO.ORDER.LPO_NUMBER },
                    //   { "ISSUER_ACKNOWLEDGE_INVOICE", issuerview.LPO.ORDER.ISSUER_ACKNOWLEDGE_INVOICE },
                    //   { "ISSUER_ACKNOWLEDGE_REMARKS", issuerview.LPO.ORDER.ISSUER_ACKNOWLEDGE_REMARKS },
                    //   { "NKEY", "AAAAAAA" },
                    //   { "CHANNEL", "W" },
                    //};

                    var datacol = new Dictionary<string, string>
                {
                   { "LPO_ISSUER_ID", issuerid },
                   { "LPO_NUMBER", lponumber },
                   { "ISSUER_ACKNOWLEDGE_INVOICE", yesno },
                   { "ISSUER_ACKNOWLEDGE_REMARKS", remark },
                   { "NKEY", nkey },
                   { "CHANNEL", "W" },
                };
                    var content = new FormUrlEncodedContent(datacol);
                    var acknowledgeinvoice = _configuration["acknowledgeinvoice"];
                    using (var response = await httpClient.PostAsync(acknowledgeinvoice, content))
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        var paytermlist = JsonConvert.DeserializeObject<IssuerVM>(apiResponse);

                        if (paytermlist.ERROR.errorcode == "0")
                        {
                            TempData["Message"] = "Your record has been Saved Successfully ";
                        }
                        else
                        {
                            TempData["Message"] = paytermlist.ERROR.errordescription;
                        }

                        return Json(new { redirectToUrl = Url.Action("GenInvoiceList", "Issuers", null) });
                        //return RedirectToAction(nameof(GenInvoiceList));

                    }

                }
            }


        }

        [HttpGet]
        public async Task<IActionResult> DashBoard()
        {
            
            string nkey = GetIPAddress();
            var userID = HttpContext.Session.GetString("UserID");
            var j = Convert.ToInt32(userID);
            var userid = j.ToString();
            DashBoardViewM dashboard = new DashBoardViewM();


            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "LPO_ISSUER_ID", userid },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);
                var issuerrdashboard = _configuration["issuerrdashboard"];
                using (var response = await httpClient.PostAsync(issuerrdashboard, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<DashBoardVM>(apiResponse);
                    //__INVESTING_STAGE investor = new _1();
                    dashboard.DashBoardVM = paytermlist;
                }

            }
            return View(dashboard);
        }

        public async Task<IActionResult> PersonalView()
        {
            var IssuerssessionInfo = JsonConvert.DeserializeObject<ObjectSession>(HttpContext.Session.GetString("issuersession"));
            var Email = IssuerssessionInfo.Email;
            var Password = IssuerssessionInfo.Password;
            //var Email = "gboladeshada@gmail.com";
            //var Password = "4545";


            string nkey = GetIPAddress();
            PersonalInfoModel responsedes = new();
            using (var httpClient = new HttpClient())
            {
                var data = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "EMAILADDRESS", Email },
                   { "xPASSWORD", Password },
                   { "TYPE_OF_ACTOR", "LPO_ISSUER" }
                };
                var content = new FormUrlEncodedContent(data);
                var loginwithemail = _configuration["loginwithemail"];
                using (var response = await httpClient.PostAsync(loginwithemail, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    responsedes = JsonConvert.DeserializeObject<PersonalInfoModel>(apiResponse);
                }
            }
            return View("PersonalInfo", responsedes);
        }

        [HttpGet]
        public async Task<IActionResult> ViewLPODetails()
        {
            
            string nkey = GetIPAddress();
            var lpoid = HttpContext.Request.Path.Value.Split('/').Last();
            IssueInvestorVM issueInvestor = new IssueInvestorVM();
            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "LPO_NUMBER", lpoid },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);
                var getlpoorder = _configuration["getlpoorder"];
                using (var response = await httpClient.PostAsync(getlpoorder, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<IssuerVM>(apiResponse);
                    _INVESTOR investor = new _INVESTOR();
                    investor.Remark = "";
                    issueInvestor.IssuerVM = paytermlist;
                }

            }
            return View(issueInvestor);
        }
        public ActionResult ChangePassword()
        {
            return View();
        }
        [HttpPost]
        public async Task<JsonResult> SubmitChangePassword(ChangePasswordData changepassdata)
        {
            IHttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
            var userID = _httpContextAccessor.HttpContext.Session.GetString("UserID");
            var j = Convert.ToInt32(userID);
            var userid = j.ToString();

            bool haserror = false;

            LPO lpo = new LPO();
            string oldpass = changepassdata.oldpass;
            string newpass = changepassdata.newpass;
            string confirmpass = changepassdata.confirmpass;


            string nkey = GetIPAddress();
            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "TYPE_OF_ACTOR","LPO_ISSUER"},
                   { "ID", userid },
                   { "OLDPASSWORD", oldpass },
                   { "NEWPASSWORD", newpass },
                   { "CONFIRMPASSWORD", confirmpass },
                   { "NKEY", nkey },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);
                var changepassword = _configuration["changepassword"];
                using (var response = await httpClient.PostAsync(changepassword, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<ERROR>(apiResponse);
                    if (result.errorcode == "0")
                    {
                        haserror = false;
                        //return Json(new { redirectToUrl = Url.Action("Home", "Borrower", lpo) });
                    }
                    else
                    {
                        haserror = true;
                        //return Json(new { redirectToUrl = 0 });
                    }

                }

            }
            if (!haserror)
            {

                return Json(new { redirectToUrl = Url.Action("Home", "Issuers", lpo) });
            }
            else
            {

                return Json(new { redirectToUrl = "" });
            }


        }

        public string GetIPAddress()
        {
            var IssuersessionInfo = JsonConvert.DeserializeObject<ObjectSession>(HttpContext.Session.GetString("issuersession"));
            var Email = IssuersessionInfo.Email;

            IPAddress remoteIpAddress = Request.HttpContext.Connection.RemoteIpAddress;
            string result = "";
            string result2 = "";
            if (remoteIpAddress != null)
            {
                // If we got an IPV6 address, then we need to ask the network for the IPV4 address 
                // This usually only happens when the browser is on the same machine as the server.
                if (remoteIpAddress.AddressFamily == System.Net.Sockets.AddressFamily.InterNetworkV6)
                {
                    remoteIpAddress = System.Net.Dns.GetHostEntry(remoteIpAddress).AddressList
                    .First(x => x.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork);
                }
                result = remoteIpAddress.ToString();
            }
            var nkeyresult = HttpContext.Session.GetString("nkey");
            string MachineName1 = Environment.MachineName;
            result2 = Email + " " + "LPO_ISSUER" + " " + MachineName1 + " " + result + " " + nkeyresult;
            //result2= string.Format($"{MachineName1} {result}");
            return result2;
        }

        public ActionResult Cancelredirect()
        {
            return RedirectToAction("Home", "Issuers", new { area = "Issuers" });
        }
        public async Task<IActionResult> SignOutAsync()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

            HttpContext.Session.Remove("UserID");
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home", new { area = "" });
        }
    }
}
