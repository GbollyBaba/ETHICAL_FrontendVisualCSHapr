﻿using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;

namespace EthicalVendor.Areas.Merchant.Controllers
{
    public class ErrorController : Controller
    {
        [Route("Error")]
        public IActionResult Error()
        {
            var exceptionhandler = HttpContext.Features.Get<IExceptionHandlerPathFeature>();
            ViewBag.ExceptionPath = exceptionhandler.Path;
            ViewBag.ExceptionError = exceptionhandler.Error.Message;
            ViewBag.StackTrace = exceptionhandler.Error.StackTrace;
            return View();
        }
    }
}
