﻿using EthicalVendor.Areas.Borrower.Models;
using EthicalVendor.Models;
using EthicalVendor.Models.ViewModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace EthicalVendor.Areas.Merchant.Controllers
{
    [Area("Merchant")]
    public class MerchantController : Controller
    {
        private IConfiguration _configuration;
        private IWebHostEnvironment _hostEnvironment;
        public MerchantController(IWebHostEnvironment environment, IConfiguration configuration)
        {
            _hostEnvironment = environment;
            _configuration = configuration;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public async Task<JsonResult> LPOlistData()
        {
            
            string nkey = GetIPAddress();
            //LPOList paytermlist = new LPOList();
            using (var httpClient = new HttpClient())
            {
                IHttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
                var userID = _httpContextAccessor.HttpContext.Session.GetString("UserID");
                var j = Convert.ToInt32(userID);
                var userid = j.ToString();
                var datacol = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "SUPPLIER_ID", userid },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);

                using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/EthSol_List_CONFIRMED_LPO_ORDER_BY_SUPPLIER", content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<LPOList>(apiResponse);
                    //var convertedJson = JsonConvert.SerializeObject(paytermlist);
                   
                    List<LPO> taiwo = new List<LPO>();
                    
                    if (paytermlist.LPOs ==null)
                    {
                        LPO lpo = new LPO();
                        lpo.BORROWER_COST = "No Record";
                        lpo.LPO_NUMBER = "No Record";
                        lpo.VAL_OF_PO = "No Record";
                        lpo.LPO_TOTAL_PRICE = "No Record";
                        lpo.LPO_ITEM_DESCRIPTION = "No Record";
                        lpo.LPO_ORDER_ID = "No Record";
                        taiwo.Add(lpo);
                        return Json(new { data = taiwo.ToArray() });

                    }
                    foreach (var obj in paytermlist.LPOs)
                    {
                        LPO lpo = new LPO();
                        lpo.country = obj.country;
                        lpo.BORROWER_COST = Convert.ToDecimal(obj.BORROWER_COST).ToString("N");
                        lpo.LPO_NUMBER = obj.LPO_NUMBER;
                        lpo.VAL_OF_PO = Convert.ToDecimal(obj.VAL_OF_PO).ToString("N");
                        lpo.LPO_TOTAL_PRICE = obj.LPO_TOTAL_PRICE;
                        lpo.LPO_ITEM_DESCRIPTION = obj.LPO_ITEM_DESCRIPTION;
                        lpo.LPO_ORDER_ID = obj.LPO_ORDER_ID;
                        taiwo.Add(lpo);

                    }
                    return Json(new { data = taiwo.ToArray() });
                    
                }

            }

        }

        [HttpGet]
        public async Task<IActionResult> ConfirmLPO(string id)
        {
            
            string nkey = GetIPAddress() ;
            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "LPO_NUMBER", id },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);

                using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/EthSol_Get_LPO_ORDER", content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<IssuerVM>(apiResponse);
                    _INVESTOR investor = new _INVESTOR();
                    //investor.Amount = "";
                    investor.Remark = "";
                    IssueInvestorVM issueInvestor = new IssueInvestorVM();
                    issueInvestor.IssuerVM = paytermlist;
                    issueInvestor.INVESTOR = investor;
                    return View(issueInvestor);
                }

            }
        }

        [HttpPost]     
        public async Task<IActionResult> GenerateInvoiceWithRemark(IssueInvestorVM issuerview,string Submit)
        {

            var t = Request;
            //if (Submit == "Submit")
            if (Submit == null)
            {
                IHttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
                var userID = _httpContextAccessor.HttpContext.Session.GetString("UserID");
                var j = Convert.ToInt32(userID);
                var userid = j.ToString();

               
                string nkey = GetIPAddress() ;

                using (var httpClient = new HttpClient())
                {
                    var datacol = new Dictionary<string, string>
                {
                   { "LPO_SUPPLIER_COY_ID", issuerview.IssuerVM.LPO.ISSUER.LPO_ISSUER_ID },
                   { "LPO_NUMBER", issuerview.IssuerVM.LPO.ORDER.LPO_NUMBER },
                   { "INVOICE_REMARKS", issuerview.IssuerVM.LPO.ORDER.INVOICE_REMARKS },
                   { "NKEY", nkey },
                   { "CHANNEL", "W" },
                };
                    var content = new FormUrlEncodedContent(datacol);

                    using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/EthSol_GENERATE_INVOICE_LPO_ORDER", content))
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        var paytermlist = JsonConvert.DeserializeObject<_LPO>(apiResponse);

                        if (paytermlist.ORDER.INVOICE_GENERATE == "Y")
                        {
                            
                            TempData["Message"] = "Your record has been Saved Successfully ";
                            return View("Invoice", paytermlist);

                        }
                        else
                        {
                            TempData["Message"] = "Error : Invoice Cannot be generated";
                            return RedirectToAction(nameof(Index));
                        }

                    }

                }
            }
            else
            {
                //return RedirectToAction(nameof(Index));
                return RedirectToAction("ConfirmLPO", new { id = issuerview.IssuerVM.LPO.ORDER.LPO_NUMBER });
            }



        }



        [HttpGet]
        public async Task<IActionResult> ViewLPODetails()
        {
            var lpoid = HttpContext.Request.Path.Value.Split('/').Last();
            IssueInvestorVM issueInvestor = new IssueInvestorVM();

            string nkey = GetIPAddress();
            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "LPO_NUMBER", lpoid },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);
                var getlpoorder = _configuration["getlpoorder"];
                using (var response = await httpClient.PostAsync(getlpoorder, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<IssuerVM>(apiResponse);
                    if (paytermlist.errorcode != null && paytermlist.errorcode == "-2000")
                    {
                        RedirectToAction("SignOutAsync", "Borrower", new { area = "Borrower" });
                    }
                    else
                    {
                        _INVESTOR investor = new _INVESTOR();
                        investor.Remark = "";
                        issueInvestor.IssuerVM = paytermlist;
                        //return View(issueInvestor);
                    }

                }
                return View(issueInvestor);
            }

            //
        }


        //[HttpPost]
        //public FileResult ExportExcel_1(string ExportData)
        //{
        //    System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
        //    using (MemoryStream stream = new System.IO.MemoryStream())
        //    {
        //        StringReader reader = new StringReader(ExportData);
        //        Document PdfFile = new Document(PageSize.A4);
        //        PdfWriter writer = PdfWriter.GetInstance(PdfFile, stream);
        //        PdfFile.Open();
        //        XMLWorkerHelper.GetInstance().ParseXHtml(writer, PdfFile, reader);
        //        PdfFile.Close();
        //        return File(stream.ToArray(), "application/pdf", "ExportData.pdf");
        //    }
        //}


        [HttpGet]
        public async Task<IActionResult> DashBoard()
        {
           
            string nkey = GetIPAddress() ;

            var userID = HttpContext.Session.GetString("UserID");
            var j = Convert.ToInt32(userID);
            var userid = j.ToString();
            DashBoardViewM dashboard = new DashBoardViewM();
            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "LPO_SUPPLIER_COY_ID", userid },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);

                using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/EthSol_Get_SUPPLIER_DASHBOARD", content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<DashBoardVM>(apiResponse);
                    //__INVESTING_STAGE investor = new _1();
                    dashboard.DashBoardVM = paytermlist;
                }

            }
            return View(dashboard);
        }

        public async Task<IActionResult> PersonalView()
        {
            
            string nkey = GetIPAddress();
            var MerchantSessionInfo = JsonConvert.DeserializeObject<ObjectSession>(HttpContext.Session.GetString("supliersession"));
           
            var Email = MerchantSessionInfo.Email;
            var Password = MerchantSessionInfo.Password;
            //var Password = "4545";

            PersonalInfoModel responsedes = new();
            using (var httpClient = new HttpClient())
            {
                var data = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "EMAILADDRESS", Email },
                   { "xPASSWORD", Password },
                   { "TYPE_OF_ACTOR", "LPO_SUPPLIER_COY" }
                };
                var content = new FormUrlEncodedContent(data);

                using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/EthSol_LoginWithEmail", content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    responsedes = JsonConvert.DeserializeObject<PersonalInfoModel>(apiResponse);
                }
            }
            return View("PersonalInfo", responsedes);
        }

        public string GetIPAddress()
        {
            var SuppliersessionInfo = JsonConvert.DeserializeObject<ObjectSession>(HttpContext.Session.GetString("supliersession"));
            var Email = SuppliersessionInfo.Email;

            IPAddress remoteIpAddress = Request.HttpContext.Connection.RemoteIpAddress;
            string result = "";
            string result2 = "";
            if (remoteIpAddress != null)
            {
                // If we got an IPV6 address, then we need to ask the network for the IPV4 address 
                // This usually only happens when the browser is on the same machine as the server.
                if (remoteIpAddress.AddressFamily == System.Net.Sockets.AddressFamily.InterNetworkV6)
                {
                    remoteIpAddress = System.Net.Dns.GetHostEntry(remoteIpAddress).AddressList
                    .First(x => x.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork);
                }
                result = remoteIpAddress.ToString();
            }
            var nkeyresult = HttpContext.Session.GetString("nkey");
            string MachineName1 = Environment.MachineName;
            result2 = Email + " " + "LPO_SUPPLIER_COY" + " " + MachineName1 + " " + result + " " + nkeyresult;
            //result2= string.Format($"{MachineName1} {result}");
            return result2;
        }

        public ActionResult ChangePassword()
        {
            return View();
        }

        [HttpPost]
        public async Task<JsonResult> SubmitChangePassword(ChangePasswordData changepassdata)
        {
            IHttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
            var userID = _httpContextAccessor.HttpContext.Session.GetString("UserID");
            var j = Convert.ToInt32(userID);
            var userid = j.ToString();

            bool haserror = false;

            LPO lpo = new LPO();
            string oldpass = changepassdata.oldpass;
            string newpass = changepassdata.newpass;
            string confirmpass = changepassdata.confirmpass;


            string nkey = GetIPAddress();
            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "TYPE_OF_ACTOR","LPO_SUPPLIER_COY"},
                   { "ID", userid },
                   { "OLDPASSWORD", oldpass },
                   { "NEWPASSWORD", newpass },
                   { "CONFIRMPASSWORD", confirmpass },
                   { "NKEY", nkey },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);
                var changepassword = _configuration["changepassword"];
                using (var response = await httpClient.PostAsync(changepassword, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<ERROR>(apiResponse);
                    if (result.errorcode == "0")
                    {
                        haserror = false;
                        //return Json(new { redirectToUrl = Url.Action("Home", "Borrower", lpo) });
                    }
                    else
                    {
                        haserror = true;
                        //return Json(new { redirectToUrl = 0 });
                    }

                }

            }
            if (!haserror)
            {

                return Json(new { redirectToUrl = Url.Action("Index", "Merchant", lpo) });
            }
            else
            {

                return Json(new { redirectToUrl = "" });
            }


        }
        public ActionResult Cancelredirect()
        {
            return RedirectToAction("Index", "Merchant", new { area = "Merchant" });
        }

        public async Task<IActionResult> SignOutAsync()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

            HttpContext.Session.Remove("UserID");
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home", new { area = "" });
        }
    }
}
