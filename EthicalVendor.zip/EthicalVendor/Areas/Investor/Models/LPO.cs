﻿using Microsoft.AspNetCore.Mvc;

namespace EthicalVendor.Areas.Investor.Models
{
    [BindProperties]
    public class LPO
    {

        public string ALLOCATED_PROFIT { get; set; }
        public string BORROWER_COST { get; set; }
        public string COUNTRY { get; set; }
        public string COY_NAME { get; set; }
        public string DATE_INV_NEEDED { get; set; }
        public string DATE_ISSUER_CONFIRM { get; set; }
        public string DATE_REQUEST { get; set; }
        public string INV_CAP_REQUIRED { get; set; }
        public string ISSUER_CONFIRMATION { get; set; }
        public string ISSUER_CONFIRMATION_ID { get; set; }
        public string ISSUER_CONFIRMATION_REMARKS { get; set; }
        public string INITIAL_INVESTMENT_BY_BORROWER { get; set; }
        public string INVESTED_FUND_SOFAR { get; set; }
        public string ISSUER_PAY_ONTIME { get; set; }
        public string LPO_DUE_DATE { get; set; }
        public string LPO_ELIGIBILITY { get; set; }
        public string LPO_ISSUER_PAYTERMS_ID { get; set; }
        public string LPO_ITEM_DESCRIPTION { get; set; }
        public string LPO_LINE_PRICE { get; set; }
        public string LPO_NUMBER { get; set; }
        public string LPO_ORDER_ID { get; set; }
        public string LPO_QUANTITY { get; set; }
        public string LPO_TOTAL_PRICE{ get; set; }
        public string LPO_UNIT_PRICE { get; set; }
        public string MATERIAL_SOURCE_COUNTRY_ID { get; set; }
        public string PAY_TERMS_DESC { get; set; }
        public string PERCENT_CONTRIBUTION { get; set; }
        public string PROFIT_AVAIL_TO_SHARE { get; set; }
        public string PROFIT_SHARE_RATION { get; set; }
        public string STATUS { get; set; }
        public string VAL_OF_PO { get; set; }
        public string LPO_ISSUER_ID { get; set; }
        
       

        //[JsonPropertyName("VAL_OF_PO")]
        //public string VAL_OF_PO { get; set; }
        //public string BorrowerCost { get; set; }
        //[JsonPropertyName("BORROWER_COST")]
        //public string BORROWER_COST { get; set; }
        //[JsonPropertyName("DATE_INV_NEEDED")]
        //public DateTime DATE_INV_NEEDED { get; set; }
        //public DateTime DateInVestmentNeeded { get; set; }
        //public string MateriaSourceCountryID { get; set; }
        //public string IssuerPayOnTime { get; set; }
        
        //public string LpoNumber { get; set; }
        //[JsonPropertyName("LPO_NUMBER")]
        //public string LPO_NUMBER { get; set; }
        //public string LPOSupplierComapnyID { get; set; }
        //[JsonPropertyName("LPO_ITEM_DESCRIPTION")]
        //public string LPO_ITEM_DESCRIPTION { get; set; }
        //public string LPOItemDescription { get; set; }
       
        //public string LPOQuantity { get; set; }
        //[JsonPropertyName("LPO_QUANTITY")]
        //public string LPO_QUANTITY { get; set; }
        //public string LPOUnitPrice { get; set; }
        //public string LPOLinePrice { get; set; }
        //[JsonPropertyName("LPO_TOTAL_PRICE")]
        //public string LPO_TOTAL_PRICE { get; set; }
        //[JsonPropertyName("LPO_ORDER_ID")]
        //public string LPO_ORDER_ID { get; set; }
       
        //public IEnumerable<EthicalVendor.Models.Issuer> ISSUERS { get; set; }
        //public IEnumerable<SelectListItem> issuers { get; set; }

        //public IEnumerable<SelectListItem> countries { get; set; }
        //public IEnumerable<SelectListItem> suppliercompanies { get; set; }
        //public IEnumerable<SelectListItem> payterms { get; set; }

        public LPOList LPOs { get; private set; }
    }

    
}
