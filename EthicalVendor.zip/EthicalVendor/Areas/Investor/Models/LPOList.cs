﻿using System.Collections.Generic;

namespace EthicalVendor.Areas.Investor.Models
{
    public class LPOList
    {
        public List<LPO> LPOs { get; set; }
    }

    public class ChangePasswordData
    {
        public string oldpass { get; set; }
        public string newpass { get; set; }
        public string confirmpass { get; set; }
    }
}
