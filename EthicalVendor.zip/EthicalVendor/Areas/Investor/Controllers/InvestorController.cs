﻿using EthicalVendor.Areas.Investor.Models;
using EthicalVendor.Models;
using EthicalVendor.Models.ViewModels;
using EthicalVendor.Utility;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PayStack.Net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace EthicalVendor.Areas.Investor.Controllers
{
    [Area("Investor")]
    public class InvestorController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly string token;
        private PayStackApi Paystack { get; set; }

        public InvestorController(IConfiguration configuration)
        {
            _configuration = configuration;
            token = _configuration["Payment:PaystackSK"];
            Paystack = new PayStackApi(token);
        }
        public IActionResult Index()
        {
            return View();
        }

        

        [HttpGet]
        public async Task<JsonResult> LPOListToBeFund()
        {
            
            string nkey = GetIPAddress() ;
            //LPOList paytermlist = new LPOList();
            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "TYPE_OF_ACTOR", "DATA_CONFIRMED_LPO" },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);
                var gettabledata = _configuration["gettabledata"];
                using (var response = await httpClient.PostAsync(gettabledata, content))
                {
                    //[{"name":"value"},{"name":"value"}]  sample
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<LPO[]>(apiResponse);
                    
                    return Json(new { data = paytermlist });//fundlist.ToArray()
                    //return convertedJson.ToArray();
                }

            }

        }

        [HttpGet]
        public async Task<IActionResult> ConfirmLPO(string id)
        {
            
            string nkey = GetIPAddress();
            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "LPO_NUMBER", id },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);
                var getlpoorder = _configuration["getlpoorder"];
                using (var response = await httpClient.PostAsync(getlpoorder, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<IssuerVM>(apiResponse);
                    _INVESTOR investor = new _INVESTOR();
                    //investor.Amount = "";
                    investor.Remark = "";
                    IssueInvestorVM issueInvestor = new IssueInvestorVM();
                    issueInvestor.IssuerVM = paytermlist;
                    issueInvestor.INVESTOR = investor;
                    return View(issueInvestor);
                }

            }
        }

        [HttpPost]
        public async Task<IActionResult> InvestorFundApproval(IssueInvestorVM issuerview)
        {
            
            string nkey = GetIPAddress() ;
            using (var httpClient = new HttpClient())
            {
                IHttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
                var userID = _httpContextAccessor.HttpContext.Session.GetString("UserID");

                var status = _httpContextAccessor.HttpContext.Session.GetString("InvestorType");

                var j = Convert.ToInt32(userID);
                var userid = j.ToString();
                var datacol = new Dictionary<string, string>
                {
                   //{ "LPO_INVESTOR_ID", issuerview.IssuerVM.LPO.ISSUER.LPO_ISSUER_ID },
                   { "LPO_INVESTOR_ID", userid },
                   { "LPO_NUMBER", issuerview.IssuerVM.LPO.ORDER.LPO_NUMBER },
                   { "AMOUNT", issuerview.INVESTOR.Amount.ToString() },
                   { "REMARKS", issuerview.INVESTOR.Remark },
                   { "NKEY", nkey },
                   { "CHANNEL", "W" },
                   { "STATUS", status }
                };
                var content = new FormUrlEncodedContent(datacol);
                var fundlpoorder = _configuration["fundlpoorder"];
                using (var response = await httpClient.PostAsync(fundlpoorder, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<IssuerVM>(apiResponse);

                    if (paytermlist.ERROR.errorcode == "0")
                    {
                        TempData["Message"] = paytermlist.ERROR.errordescription;
                    }
                    else
                    {
                        TempData["Message"] = paytermlist.ERROR.errordescription;
                    }

                    return RedirectToAction(nameof(Index));
                    //return View(paytermlist);
                }

            }

        }

        [HttpPost]
        
        public async Task<IActionResult> PayFundIndex(IssueInvestorVM issuerview, string Submit)
        {
            if (Submit == null)
            {
                //your "Save" button code here.. 
                IHttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
                var userID = _httpContextAccessor.HttpContext.Session.GetString("UserID");
                var Email = _httpContextAccessor.HttpContext.Session.GetString("Email");
                Email = Email.Replace("\"", "");
                HttpContext.Session.SetObject("LPONUMBER", issuerview.IssuerVM.LPO.ORDER.LPO_NUMBER.Trim());
                //Validate The Fund Before Submiting to Paystack
                int amount = issuerview.INVESTOR.Amount * 100;

                string valresult = await ValidateFund(userID, issuerview.IssuerVM.LPO.ORDER.LPO_NUMBER.Trim(), issuerview.INVESTOR.Amount.ToString(), issuerview.INVESTOR.Remark);
                var callbackUrl = _configuration["CallbackUrl"];

                if (valresult == "Y")
                {
                    TransactionInitializeRequest request = new()
                    {
                        AmountInKobo = issuerview.INVESTOR.Amount * 100,
                        Email = Email,/*issuerview.INVESTOR.Email*/
                        Reference = Generate().ToString(),
                        Currency = "NGN",
                        CallbackUrl = callbackUrl
                    };

                    //CallbackUrl = "http://localhost:5000/investor/investor/verify"
                    TransactionInitializeResponse response = Paystack.Transactions.Initialize(request);
                    if (response.Status)
                    {
                        return Redirect(response.Data.AuthorizationUrl);
                    }
                    ViewData["error"] = response.Message;
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    TempData["Message"] = "Your Fund is not acceptable,kindly contact admin for further details";
                    return RedirectToAction(nameof(Index));
                }
            }
            else
            {
                //your "Cancel" button code here..
                return RedirectToAction(nameof(Index));
            }

          
        }

        [HttpGet]
        public async Task<IActionResult> Verify(string reference)
        {
            
            string nkey = GetIPAddress() ;
            TransactionVerifyResponse response = Paystack.Transactions.Verify(reference);
            if (response.Data.Status == "success")
            {
                int Amount = response.Data.Amount/100;

                /*var transaction = _context.Transactions.Where(x => x.TrxRef == reference).FirstOrDefault();
                if (transaction != null)
                {
                    transaction.Status = true;
                    _context.Transactions.Update(transaction);
                    await _context.SaveChangesAsync();
                    return RedirectToAction("Donations");
                }*/
                using (var httpClient = new HttpClient())
                {
                    IHttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
                    var userID = _httpContextAccessor.HttpContext.Session.GetString("UserID");
                    var LPO_Number = _httpContextAccessor.HttpContext.Session.GetString("LPONUMBER").Trim();
                    var status = _httpContextAccessor.HttpContext.Session.GetString("InvestorType");
                    LPO_Number = LPO_Number.Replace("\"", "");
                    status = status.Replace("\"", "");
                    var j = Convert.ToInt32(userID);
                    var userid = j.ToString();
                    var datacol = new Dictionary<string, string>
                    {
                       //{ "LPO_INVESTOR_ID", issuerview.IssuerVM.LPO.ISSUER.LPO_ISSUER_ID },
                       { "LPO_INVESTOR_ID", userid },
                       { "LPO_NUMBER", LPO_Number},
                       { "AMOUNT", Amount.ToString() },
                       { "REMARKS", reference },
                       { "NKEY", nkey },
                       { "CHANNEL", "W" },
                       { "STATUS", status }
                    };
                    var content = new FormUrlEncodedContent(datacol);
                    var fundlpoorder = _configuration["fundlpoorder"];
                    using (var response2 = await httpClient.PostAsync(fundlpoorder, content))
                    {
                        string apiResponse = await response2.Content.ReadAsStringAsync();
                        var paytermlist = JsonConvert.DeserializeObject<IssuerVM>(apiResponse);

                        if (paytermlist.ERROR.errorcode == "0")
                        {
                            TempData["Message"] = paytermlist.ERROR.errordescription;
                        }
                        else
                        {
                            TempData["Message"] = paytermlist.ERROR.errordescription;
                        }

                        return RedirectToAction(nameof(Index));
                       
                    }

                }
            }
            ViewData["error"] = response.Data.GatewayResponse;
            return RedirectToAction("Index");
        }

        public static int Generate()
        {
            Random rand = new Random((int)DateTime.Now.Ticks);
            return rand.Next(100000000, 999999999);
        }

        [HttpGet]
        public async Task<IActionResult> DashBoard()
        {
           
            string nkey = GetIPAddress() ;
            var userID = HttpContext.Session.GetString("UserID");
            var j = Convert.ToInt32(userID);
            var userid = j.ToString();
            DashBoardViewM dashboard = new DashBoardViewM();
            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "LPO_INVESTOR_ID", userid },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);
                var investordashboard = _configuration["investordashboard"];
                using (var response = await httpClient.PostAsync(investordashboard, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<DashBoardVM>(apiResponse);
                    //__INVESTING_STAGE investor = new _1();
                    dashboard.DashBoardVM = paytermlist;
                }

            }
            return View(dashboard);
        }
        public async Task<string> ValidateFund(string InvestorID,string LpoNumber,string Amount,string Remark)
        {
            
            string nkey = GetIPAddress() ;
            IHttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
            var InvestorType = _httpContextAccessor.HttpContext.Session.GetString("InvestorType");
            InvestorType = InvestorType.Replace("\"", "");
            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "LPO_INVESTOR_ID", InvestorID },
                   { "AMOUNT", Amount },
                   { "REMARKS", Remark },
                   { "NKEY", nkey },
                   { "LPO_NUMBER", LpoNumber },
                   { "CHANNEL", "W" },
                   { "STATUS", InvestorType },
                };
                var content = new FormUrlEncodedContent(datacol);  //Statu P ,C  
                var validatefundlpoorder = _configuration["validatefundlpoorder"];
                using (var response = await httpClient.PostAsync(validatefundlpoorder, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var valresult = JsonConvert.DeserializeObject<VALIDATE>(apiResponse);
                    string valresultstring = valresult.ALLOW_FUNDING;
                    return valresultstring;
                }

            }
        }

        [HttpGet]
        public async Task<IActionResult> ViewLPODetails()
        {
            
            string nkey = GetIPAddress() ;
            var lpoid = HttpContext.Request.Path.Value.Split('/').Last();
            IssueInvestorVM issueInvestor = new IssueInvestorVM();
            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "LPO_NUMBER", lpoid },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);
                var getlpoorder = _configuration["getlpoorder"];
                using (var response = await httpClient.PostAsync(getlpoorder, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<IssuerVM>(apiResponse);
                    issueInvestor.IssuerVM = paytermlist;
                }

            }
            return View(issueInvestor);
        }
        public async Task<IActionResult> PersonalView()
        {
            var InvestorsessionInfo = JsonConvert.DeserializeObject<ObjectSession>(HttpContext.Session.GetString("investorsession"));

            var Email = InvestorsessionInfo.Email;
            //var Email = "gboladeshada@gmail.com";
            var Password = "1234";


            string nkey = GetIPAddress();
            IHttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
            var InvestorType = _httpContextAccessor.HttpContext.Session.GetString("InvestorType");
            InvestorType = InvestorType.Replace("\"", "");
            string mytype = InvestorType != "C" ? "LPO_INVESTOR" : "LPO_INVESTOR_COY";
            

            
            

            PersonalInfoModel responsedes = new();
            using (var httpClient = new HttpClient())
            {
                var data = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "EMAILADDRESS", Email },
                   { "xPASSWORD", Password },
                   { "TYPE_OF_ACTOR", mytype }
                };
                var content = new FormUrlEncodedContent(data);


                var loginwithemail = _configuration["loginwithemail"];
                using (var response = await httpClient.PostAsync(loginwithemail, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    responsedes = JsonConvert.DeserializeObject<PersonalInfoModel>(apiResponse);
                    //ViewComponent(typeof(PersonalViewComponent), responsedes);
                }


            }
            //return  ViewComponent(typeof(PersonalViewComponent), responsedes);
            return View("PersonalInfo", responsedes);
        }
        public string GetIPAddress()
        {
            var SuppliersessionInfo = JsonConvert.DeserializeObject<ObjectSession>(HttpContext.Session.GetString("investorsession"));
            var Email = SuppliersessionInfo.Email;

            IHttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
            var InvestorType = _httpContextAccessor.HttpContext.Session.GetString("InvestorType");
            InvestorType = InvestorType.Replace("\"", "");
            string mytype = InvestorType != "C" ? "LPO_INVESTOR" : "LPO_INVESTOR_COY";

            IPAddress remoteIpAddress = Request.HttpContext.Connection.RemoteIpAddress;
            string result = "";
            string result2 = "";
            if (remoteIpAddress != null)
            {
                // If we got an IPV6 address, then we need to ask the network for the IPV4 address 
                // This usually only happens when the browser is on the same machine as the server.
                if (remoteIpAddress.AddressFamily == System.Net.Sockets.AddressFamily.InterNetworkV6)
                {
                    remoteIpAddress = System.Net.Dns.GetHostEntry(remoteIpAddress).AddressList
                    .First(x => x.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork);
                }
                result = remoteIpAddress.ToString();
            }
            var nkeyresult = HttpContext.Session.GetString("nkey");
            string MachineName1 = Environment.MachineName;
            result2 = Email + " " + mytype + " " + MachineName1 + " " + result + " " + nkeyresult;
            //result2= string.Format($"{MachineName1} {result}");
            return result2;
        }
        public ActionResult ChangePassword()
        {
            return View();
        }
        [HttpPost]
        public async Task<JsonResult> SubmitChangePassword(ChangePasswordData changepassdata)
        {
            IHttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
            var userID = _httpContextAccessor.HttpContext.Session.GetString("UserID");
            var j = Convert.ToInt32(userID);
            var userid = j.ToString();

            var InvestorType = _httpContextAccessor.HttpContext.Session.GetString("InvestorType");
            InvestorType = InvestorType.Replace("\"", "");
            string mytype = InvestorType != "C" ? "LPO_INVESTOR" : "LPO_INVESTOR_COY";

            bool haserror = false;

            LPO lpo = new LPO();
            string oldpass = changepassdata.oldpass;
            string newpass = changepassdata.newpass;
            string confirmpass = changepassdata.confirmpass;


            string nkey = GetIPAddress();
            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "TYPE_OF_ACTOR",mytype},
                   { "ID", userid },
                   { "OLDPASSWORD", oldpass },
                   { "NEWPASSWORD", newpass },
                   { "CONFIRMPASSWORD", confirmpass },
                   { "NKEY", nkey },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);
                var changepassword = _configuration["changepassword"];
                using (var response = await httpClient.PostAsync(changepassword, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<ERROR>(apiResponse);
                    if (result.errorcode == "0")
                    {
                        haserror = false;
                        //return Json(new { redirectToUrl = Url.Action("Home", "Borrower", lpo) });
                    }
                    else
                    {
                        haserror = true;
                        //return Json(new { redirectToUrl = 0 });
                    }

                }

            }
            if (!haserror)
            {

                return Json(new { redirectToUrl = Url.Action("Home", "Investor", lpo) });
            }
            else
            {

                return Json(new { redirectToUrl = "" });
            }


        }


        public ActionResult Cancelredirect()
        {
            return RedirectToAction("Index", "Investor", new { area = "Investor" });
        }
        public async Task<IActionResult> SignOutAsync()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

            HttpContext.Session.Remove("UserID");
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home", new { area = "" });
        }
    }

}
