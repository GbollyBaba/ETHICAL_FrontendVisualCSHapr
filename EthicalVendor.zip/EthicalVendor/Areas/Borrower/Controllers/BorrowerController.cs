﻿using EthicalVendor.Areas.Borrower.Models;
using EthicalVendor.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Google.Apis.Auth.OAuth2;
using Google.Cloud.Storage.V1;
using Microsoft.Extensions.Configuration;
using EthicalVendor.Utility;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using PayStack.Net;
using EthicalVendor.Models.ViewModels;
using EthicalVendor.ViewComponents;
using System.Net;

namespace EthicalVendor.Areas.Borrower.Controllers
{
    [Area("Borrower")]
    public class BorrowerController : Controller
    {
        private IConfiguration _configuration;
        private readonly string token;
        public string ClientIPAddr { get; private set; }
        private PayStackApi Paystack { get; set; }

        //public BorrowerController(IConfiguration Iconfig)
        public BorrowerController(IConfiguration configuration)
        {
            IHttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
            //configuration = Iconfig;
            _configuration = configuration;
            token = _configuration["Payment:PaystackSK"];
            Paystack = new PayStackApi(token);



        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SummaryPage2(LPO lpo)
        {
            return View(lpo);
        }
        public async Task<IActionResult> Home()
        {
            //var bankload = await LoadBank();
            var res = await LoadIssuer();
            var country = await LoadCountry();
            var supplier = await LoadCompanySuppliers();
            var payterm = await LoadPayTerm();
            var termmeasure = await LoadItermMearsurement();
            LPO lpo = new LPO();
            lpo.countries = country;
            lpo.issuers = res;
            lpo.suppliercompanies = supplier;
            lpo.payterms = payterm;
            lpo.termmeasurements = termmeasure;
            return View(lpo);
        }

        [HttpGet]
        public async Task<IEnumerable<SelectListItem>> LoadIssuer()
        {



            string nkey = GetIPAddress();
            //var contryList = new CountryResponse();
            using (var httpClient = new HttpClient())
            {

                var data = new Dictionary<string, string>
                {
                   //{ "NKEY", "AAAA" },
                   { "NKEY", nkey },
                   { "TYPE_OF_ACTOR", "LPO_ISSUER" }
                };
                var content = new FormUrlEncodedContent(data);


                LPO issuerss = new();
                var gettabledata = _configuration["gettabledata"];
                using (var response = await httpClient.PostAsync(gettabledata, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var issuerlist = JsonConvert.DeserializeObject<IList<Issuer>>(apiResponse);
                    if (apiResponse == null)
                    {
                        var eresponse = JsonConvert.DeserializeObject<ErrorResponse>(apiResponse);
                        if (eresponse.errorcode != null && eresponse.errorcode == "-2000")
                        {
                            //Log the user out
                             RedirectToAction("SignOutAsync", "Borrower", new { area = "Borrower" });
                        }
                    }
                    else
                    {
                        List<SelectListItem> lstselectListItem = new();
                        foreach (var issuer in issuerlist)
                        {
                            SelectListItem selectListItem2 = new SelectListItem()
                            {
                                Text = issuer.COY_NAME,
                                Value = issuer.LPO_ISSUER_ID,
                                //Selected = city.IsSelected
                            };
                            lstselectListItem.Add(selectListItem2);
                        }
                        issuerss.issuers = lstselectListItem;
                    }


                }
                return issuerss.issuers;

            }
        }

        public async Task<IEnumerable<SelectListItem>> LoadCountry()
        {
            var contryList = new CountryResponse();

            string nkey = GetIPAddress();
            using (var httpClient = new HttpClient())
            {
                var data = new Dictionary<string, string>
                {
                   //{ "NKEY", "AAAAAA" },
                   { "NKEY", nkey },
                   { "CHANNEL", "1" }
                };
                var content = new FormUrlEncodedContent(data);

                LPO countries = new();
                var getcountry = _configuration["getcountry"];
                using (var response = await httpClient.PostAsync(getcountry, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var countrylist = JsonConvert.DeserializeObject<CountryData>(apiResponse);
                    List<SelectListItem> lstselectListItem = new List<SelectListItem>();

                    foreach (var country in countrylist.COUNTRIES)
                    {
                        SelectListItem selectListItem = new SelectListItem()
                        {
                            Text = country.COUNTRY,
                            Value = country.COUNTRY_ID,
                            //Selected = city.IsSelected
                        };
                        lstselectListItem.Add(selectListItem);
                    }
                    countries.countries = lstselectListItem;
                }
                return countries.countries;
            }
        }

        [HttpGet]
        public async Task<IEnumerable<SelectListItem>> LoadCompanySuppliers()
        {

            string nkey = GetIPAddress();
            //var contryList = new CountryResponse();
            using (var httpClient = new HttpClient())
            {
                var data = new Dictionary<string, string>
                {
                   //{ "NKEY", "AAAA" },
                   { "NKEY", nkey },
                   { "TYPE_OF_ACTOR", "LPO_SUPPLIER_COY" }
                };
                var content = new FormUrlEncodedContent(data);


                LPO supplierss = new();
                var gettabledata = _configuration["gettabledata"];
                using (var response = await httpClient.PostAsync(gettabledata, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var supplierlists = JsonConvert.DeserializeObject<IList<Supplier>>(apiResponse);
                    List<SelectListItem> lstselectListItem = new List<SelectListItem>();

                    foreach (var supplier in supplierlists)
                    {
                        SelectListItem selectListItem2 = new SelectListItem()
                        {
                            Text = supplier.COY_NAME,
                            Value = supplier.LPO_SUPPLIER_COY_ID,

                        };
                        lstselectListItem.Add(selectListItem2);
                    }
                    supplierss.suppliercompanies = lstselectListItem;
                }
                return supplierss.suppliercompanies;//Json(new SelectList(issuerss.issuers, "Value", "Text"));

            }
        }

        public async Task<IEnumerable<SelectListItem>> LoadPayTerm()
        {

            string nkey = GetIPAddress();
            using (var httpClient = new HttpClient())
            {
                var data = new Dictionary<string, string>
                {
                   //{ "NKEY", "AAAA" },
                   { "NKEY", nkey },
                   { "TYPE_OF_ACTOR", "LPO_ISSUER_PAYTERMS" }
                };
                var content = new FormUrlEncodedContent(data);

                LPO paytermss = new LPO();
                var gettabledata = _configuration["gettabledata"];
                using (var response = await httpClient.PostAsync(gettabledata, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<IList<Payterm>>(apiResponse);
                    List<SelectListItem> lstselectListItem = new List<SelectListItem>();

                    foreach (var payterm in paytermlist)
                    {
                        SelectListItem selectListItem2 = new SelectListItem()
                        {
                            Text = payterm.PAY_TERMS_DESC,
                            Value = payterm.LPO_ISSUER_PAYTERMS_ID,
                            //Selected = city.IsSelected
                        };
                        lstselectListItem.Add(selectListItem2);
                    }
                    paytermss.payterms = lstselectListItem;
                }
                return paytermss.payterms;
            }
        }

        public async Task<IEnumerable<SelectListItem>> LoadItermMearsurement()
        {

            string nkey = GetIPAddress();
            using (var httpClient = new HttpClient())
            {
                var data = new Dictionary<string, string>
                {
                   //{ "NKEY", "AAAA" },
                   { "NKEY", nkey },
                   { "TYPE_OF_ACTOR", "LPO_ITEM_MEASUREMENT_TYPE" },
                   { "CHANNEL", "W" }
                };
                var content = new FormUrlEncodedContent(data);

                LPO paytermss = new LPO();
                var gettabledata = _configuration["gettabledata"];
                using (var response = await httpClient.PostAsync(gettabledata, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var termmeasurementlist = JsonConvert.DeserializeObject<IList<ItemMeasurement>>(apiResponse);
                    List<SelectListItem> lstselectListItem = new List<SelectListItem>();

                    foreach (var termmeasurement in termmeasurementlist)
                    {
                        SelectListItem selectListItem2 = new SelectListItem()
                        {
                            Text = termmeasurement.ITEM_MEASUREMENT_TYPE_DESC,
                            Value = termmeasurement.ITEM_MEASUREMENT_TYPE_ID,
                            //Selected = city.IsSelected
                        };
                        lstselectListItem.Add(selectListItem2);
                    }
                    paytermss.termmeasurements = lstselectListItem;
                }
                return paytermss.termmeasurements;
            }
        }

        private static string FormFileName(string lpoNumber, string fileName, int i)
        {
            var fileExtension = Path.GetExtension(fileName);
            var fileNameForStorage = $"{lpoNumber + "_" + i.ToString()}{fileExtension}";
            return fileNameForStorage;
        }

        [HttpGet]
        public IActionResult DownloadObjectIntoMemory(string? LPO_NUMBER)
        {
            var lpoid = HttpContext.Request.Path.Value.Split('/').Last();
            //string lpopdf = lpoid + "_0" + ".pdf";
            string lpopdf = lpoid + ".pdf";
            GoogleCredential googleCredential = GoogleCredential.FromFile(_configuration.GetValue<string>("GoogleCredentialFile"));

            var storage = StorageClient.Create(googleCredential);
            var stream = new MemoryStream();
            //storage.DownloadObject("esmsuite.appspot.com", lpopdf, stream);//
            storage.DownloadObject("esmsuite.appspot.com", lpopdf, stream);
            stream.Position = 0;
            return File(stream.ToArray(), "application/pdf");


        }


        [HttpGet]
        public async Task<IActionResult> ViewLPODetails()
        {
            var lpoid = HttpContext.Request.Path.Value.Split('/').Last();
            IssueInvestorVM issueInvestor = new IssueInvestorVM();

            string nkey = GetIPAddress();
            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "LPO_NUMBER", lpoid },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);
                var getlpoorder = _configuration["getlpoorder"];
                using (var response = await httpClient.PostAsync(getlpoorder, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<IssuerVM>(apiResponse);
                    if (paytermlist.errorcode != null && paytermlist.errorcode == "-2000")
                    {
                        RedirectToAction("SignOutAsync", "Borrower", new { area = "Borrower" });
                    }
                    else
                    {
                        _INVESTOR investor = new _INVESTOR();
                        investor.Remark = "";
                        issueInvestor.IssuerVM = paytermlist;
                        return View(issueInvestor);
                    }
                    
                }
                return View(issueInvestor);
            }

            //
        }


        [HttpPost]
        //[ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateLPO(LPO lpo)
        {


            IHttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
            var userID = _httpContextAccessor.HttpContext.Session.GetString("UserID");
            var j = Convert.ToInt32(userID);
            var userid = j.ToString();

            string nkey = GetIPAddress();
            if (ModelState.IsValid)
            {
                using (var httpClient = new HttpClient())
                {
                    /*if(lpo.LPOLinePrice.ToString()=="")
                    {
                        lpo.LPOLinePrice = 1;
                    }*/
                    var data = new Dictionary<string, string>
                    {
                       { "LPO_ISSUER_ID", lpo.issuer },
                       { "VAL_OF_PO", lpo.ValueOfPO },
                       { "BORROWER_COST", lpo.BorrowerCost},
                       { "DATE_INV_NEEDED", lpo.DateInVestmentNeeded.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "MATERIAL_SOURCE_COUNTRY_ID", lpo.country },
                       { "ISSUER_PAY_ONTIME", lpo.IssuerPayOnTime },
                       { "LPO_NUMBER",lpo.LpoNumber },
                       { "LPO_SUPPLIER_COY_ID", lpo.suppliercompany },
                       { "LPO_ITEM_DESCRIPTION", lpo.LPOItemDescription },
                       { "LPO_ITEM_MEASUREMENT_TYPE_ID", lpo.termmeasurement },
                       { "LPO_QUANTITY", lpo.LPOQuantity.ToString() },
                       { "LPO_UNIT_PRICE", lpo.LPOUnitPrice },
                       { "INITIAL_INVESTMENT_BY_BORROWER", lpo.InitialInvestment },
                       { "LPO_TOTAL_PRICE", lpo.LPOTotalPrice},
                       { "LPO_DUE_DATE", lpo.LPODueDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "LPO_ISSUER_PAYTERMS_ID", lpo.payterm },
                       { "LPO_BORROWER_ID", userid },
                       { "STATUS", "A" },
                       { "NKEY", nkey },
                       { "CHANNEL", "W" }
                    };

                    var content = new FormUrlEncodedContent(data);

                    var createlpoorder = _configuration["createlpoorder"];
                    Response responsedes = new();
                    using (var response = await httpClient.PostAsync(createlpoorder, content))
                    {

                        string apiResponse = await response.Content.ReadAsStringAsync();

                        responsedes = JsonConvert.DeserializeObject<Response>(apiResponse);
                        //responsedes.UserType = borrower.UserType;
                        //var convertedJson = JsonConvert.SerializeObject(responsedes);

                        if (responsedes.ERROR["errorcode"] == "0")
                        {
                            TempData["Message"] = responsedes.ERROR["errordescription"];// "LPO Has Been Created Suuccesfully";
                            //Upload Supporting File Here
                            using (var memoryStream = new MemoryStream())
                            {
                                string fileNameForStorage = FormFileName(lpo.LpoNumber, lpo.docFile.FileName, 1);
                                GoogleCredential googleCredential = GoogleCredential.FromFile(_configuration.GetValue<string>("GoogleCredentialFile"));
                                StorageClient storageClient = StorageClient.Create(googleCredential);
                                var storage = StorageClient.Create(googleCredential);
                                await lpo.docFile.CopyToAsync(memoryStream);
                                var dataObject = await storage.UploadObjectAsync("esmsuite.appspot.com", fileNameForStorage, null, memoryStream);
                                var mylink = dataObject.MediaLink;


                            }
                        }
                        else
                        {
                            TempData["Message"] = responsedes.ERROR["errordescription"];
                            var res1 = await LoadIssuer();
                            var country1 = await LoadCountry();
                            var supplier1 = await LoadCompanySuppliers();
                            var payterm1 = await LoadPayTerm();
                            var termmeasure1 = await LoadItermMearsurement();

                            lpo.countries = country1;
                            lpo.issuers = res1;
                            lpo.suppliercompanies = supplier1;
                            lpo.payterms = payterm1;
                            lpo.termmeasurements = termmeasure1;
                            return View("Home", lpo);
                        }
                    }

                    return RedirectToAction(nameof(LPOList));


                }
            }
            TempData["Message"] = "Invalid Data Not Allowed!!";
            var res = await LoadIssuer();
            var country = await LoadCountry();
            var supplier = await LoadCompanySuppliers();
            var payterm = await LoadPayTerm();
            var termmeasure = await LoadItermMearsurement();

            lpo.countries = country;
            lpo.issuers = res;
            lpo.suppliercompanies = supplier;
            lpo.payterms = payterm;
            lpo.termmeasurements = termmeasure;
            return View("Home", lpo);

        }

        [HttpPost]
        public IActionResult SummaryPage()
        {
            LPO lpo = new LPO();
            lpo.LpoNumber = Request.Form["LpoNumber"];
            lpo.ValueOfPO = Request.Form["ValueOfPO"];
            //lpo.LPOQuantity = int.Parse(Request.Form["LPOQuantity"]);
            //lpo.LPOUnitPrice = Request.Form["LPOUnitPrice"];

            //lpo.LPOTotalPrice = Request.Form["LPOTotalPrice"];
            lpo.issuer = Request.Form["Issuer"];
            lpo.suppliercompany = Request.Form["Suppliercompany"];
            lpo.payterm = Request.Form["Payterm"];
            lpo.country = Request.Form["Country"];
            lpo.termmeasurement = Request.Form["Termmeasurement"];
            //lpo.LPOLinePrice = Request.Form["LPOLinePrice"];
            lpo.LPODueDate = Convert.ToDateTime(Request.Form["LPODueDate"]);
            lpo.IssuerPayOnTime = Request.Form["IssuerPayOnTime"];
            lpo.DateInVestmentNeeded = Convert.ToDateTime(Request.Form["DateInVestmentNeeded"]);
            lpo.BorrowerCost = Request.Form["BorrowerCost"];
            lpo.InitialInvestment = Request.Form["initialinvestment"];
            return Json(new { redirectToUrl = Url.Action("SummaryPage2", "Borrower", lpo) });
        }

        [HttpPost]
        public async Task<IActionResult> CreateLPOAjax(IFormFile formFile)
        {
            //try
            //{
            string LpoNumber = Request.Form["LpoNumber"];
            string ValueOfPO = Request.Form["ValueOfPO"];
            string LPOItemsDesc = Request.Form["LPOItemsDesc"];
            string LPOQuantity = Request.Form["LPOQuantity"];
            string LPOUnitPrice = Request.Form["LPOUnitPrice"];

            string LPOTotalPrice = Request.Form["LPOTotalPrice"];
            string Issuer = Request.Form["Issuer"];
            string Suppliercompany = Request.Form["Suppliercompany"];
            string Payterm = Request.Form["Payterm"];
            string Country = Request.Form["Country"];
            string Termmeasurement = Request.Form["Termmeasurement"];
            string LPOLinePrice = Request.Form["LPOLinePrice"];
            string LPODueDate = Request.Form["LPODueDate"];
            string IssuerPayOnTime = Request.Form["IssuerPayOnTime"];
            string DateInVestmentNeeded = Request.Form["DateInVestmentNeeded"];
            string BorrowerCost = Request.Form["BorrowerCost"];
            string initialinvestmentbyborrower = Request.Form["initialinvestment"];
            string fileuploadNumber = Request.Form.Files.Count.ToString();


            //var taiwo = LPO_ITEMS;
            var LPO_ITEMS = Request.Form["LPO_ITEMS"];

            var file = Request.Form.Files;

            IHttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
            var userID = _httpContextAccessor.HttpContext.Session.GetString("UserID");
            var j = Convert.ToInt32(userID);
            var userid = j.ToString();


            string nkey = GetIPAddress();

            HttpContext.Session.SetObject("LPONUMBER", LpoNumber);

            var valresult = await ValidateFund(Issuer, ValueOfPO, BorrowerCost, DateInVestmentNeeded, Country, IssuerPayOnTime, LpoNumber, Suppliercompany, Termmeasurement, LPO_ITEMS, initialinvestmentbyborrower, LPODueDate, Payterm, userid);
            if (valresult.ELIGIBILITY == "Y")
            {
                using (var httpClient = new HttpClient())
                {
                    //if (LPOLinePrice.ToString() == "" || LPOLinePrice=="0")
                    //{
                    //   LPOLinePrice = "1";
                    //}
                    var data = new Dictionary<string, string>
                {
                   { "LPO_ISSUER_ID", Issuer },
                   { "VAL_OF_PO", ValueOfPO },
                   { "BORROWER_COST", BorrowerCost},
                   { "DATE_INV_NEEDED",DateInVestmentNeeded },
                   { "MATERIAL_SOURCE_COUNTRY_ID", Country },
                   { "ISSUER_PAY_ONTIME", IssuerPayOnTime },
                   { "LPO_NUMBER",LpoNumber },
                   { "LPO_SUPPLIER_COY_ID", Suppliercompany },
                   { "LPO_ITEM_MEASUREMENT_TYPE_ID", Termmeasurement },
                   { "LPO_ITEMS", LPO_ITEMS },
                   { "INITIAL_INVESTMENT_BY_BORROWER", initialinvestmentbyborrower },
                   { "LPO_DUE_DATE", LPODueDate },
                   { "LPO_ISSUER_PAYTERMS_ID", Payterm },
                   { "LPO_BORROWER_ID", userid },
                   { "STATUS", "A" },
                   { "NKEY", nkey },
                   {"NUMBER_DOCUMENTS_UPLOADED" ,fileuploadNumber},
                   { "CHANNEL", "W" }
                };

                    var content = new FormUrlEncodedContent(data);


                    Response responsedes = new();
                    var createlpoorderv4 = _configuration["createlpoorderv4"];
                    using (var response = await httpClient.PostAsync(createlpoorderv4, content))
                    {

                        string apiResponse = await response.Content.ReadAsStringAsync();

                        responsedes = JsonConvert.DeserializeObject<Response>(apiResponse);

                        if (responsedes.errorcode == "0")
                        {

                            //Upload Supporting File Here
                            using (var memoryStream = new MemoryStream())
                            {
                                string fileNameForStorage = string.Empty;

                                for (var i = 0; i < Request.Form.Files.Count; i++)
                                {
                                    fileNameForStorage = FormFileName(LpoNumber, Request.Form.Files[i].FileName.Trim(), i);
                                    GoogleCredential googleCredential = GoogleCredential.FromFile(_configuration.GetValue<string>("GoogleCredentialFile"));
                                    StorageClient storageClient = StorageClient.Create(googleCredential);
                                    var storage = StorageClient.Create(googleCredential);
                                    await file[i].CopyToAsync(memoryStream);
                                    var dataObject = await storage.UploadObjectAsync("esmsuite.appspot.com", fileNameForStorage, null, memoryStream);
                                    var mylink = dataObject.MediaLink;

                                }


                            }
                            TempData["Message"] = responsedes.errordescription;// This is white rectangle pop
                                                                               //TempData[FinanceUtility.Success] = responsedes.errordescription;//Flash green
                                                                               //Call Paystack
                            var claim = HttpContext.User.Claims.FirstOrDefault(c => c.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress");
                            var emailAddress = claim.Value;
                            var borrowerverifycallback = _configuration["borrowerverifycallback"];
                            TransactionInitializeRequest request = new()
                            {
                                AmountInKobo = int.Parse(initialinvestmentbyborrower) * 100,
                                Email = emailAddress,
                                Reference = Generate().ToString(),
                                Currency = "NGN",
                                CallbackUrl = borrowerverifycallback
                            };
                            TransactionInitializeResponse response2 = Paystack.Transactions.Initialize(request);
                            if (response2.Status)
                            {
                                //return Redirect(response2.Data.AuthorizationUrl);
                                return Json(new { redirectToUrl = response2.Data.AuthorizationUrl });
                            }
                            ViewData["error"] = response2.Message;
                            return View();
                            //return Json(new { redirectToUrl = Url.Action("LPOList", "Borrower") });
                        }
                        else
                        {

                            TempData["Message"] = responsedes.errordescription;
                            //TempData[FinanceUtility.Error] = responsedes.errordescription;
                            var res1 = await LoadIssuer();
                            var country1 = await LoadCountry();
                            var supplier1 = await LoadCompanySuppliers();
                            var payterm1 = await LoadPayTerm();
                            var termmeasure1 = await LoadItermMearsurement();

                            LPO lpo = new LPO();
                            lpo.countries = country1;
                            lpo.issuers = res1;
                            lpo.suppliercompanies = supplier1;
                            lpo.payterms = payterm1;
                            lpo.termmeasurements = termmeasure1;
                            return Json(new { redirectToUrl = Url.Action("Home", "Borrower", lpo) });
                            //return View("Home", lpo);
                        }
                    }

                    //return RedirectToAction(nameof(LPOList));

                }
            }
            else
            {
                TempData["Message"] = valresult.errordescription;
                //TempData["Message"] = "Your LPO cannot be approved by the system. Please contact admin for further details";
                return Json(new { redirectToUrl = Url.Action("Home", "Borrower", null) });
            }


            //}
            /*catch (Exception e)
            {
                TempData["Message"] = e.Message;
            }
            return Json(new { redirectToUrl = Url.Action("LPOList", "Borrower") });*/
        }

        [HttpGet]
        public async Task<IActionResult> Verify(string reference)
        {

            string nkey = GetIPAddress();

            TransactionVerifyResponse response = Paystack.Transactions.Verify(reference);
            if (response.Data.Status == "success")
            {
                int Amount = response.Data.Amount / 100;


                using (var httpClient = new HttpClient())
                {
                    IHttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
                    var userID = _httpContextAccessor.HttpContext.Session.GetString("UserID");
                    var LPO_Number = _httpContextAccessor.HttpContext.Session.GetString("LPONUMBER").Trim();
                    LPO_Number = LPO_Number.Replace("\"", "");
                    var j = Convert.ToInt32(userID);
                    var userid = j.ToString();
                    var datacol = new Dictionary<string, string>
                {

                   { "LPO_INVESTOR_ID", userid },
                   { "LPO_NUMBER", LPO_Number},
                   { "AMOUNT", Amount.ToString() },
                   { "REMARKS", reference },
                   { "NKEY", nkey },
                   { "CHANNEL", "W" },
                   { "STATUS", "B" }
                };
                    var content = new FormUrlEncodedContent(datacol);
                    var fundlpoorder = _configuration["fundlpoorder"];
                    using (var response2 = await httpClient.PostAsync(fundlpoorder, content))
                    {
                        string apiResponse = await response2.Content.ReadAsStringAsync();
                        var paytermlist = JsonConvert.DeserializeObject<Response>(apiResponse);

                        if (paytermlist.ERROR["errorcode"] == "0")
                        {
                            TempData["Message"] = paytermlist.errordescription;
                        }
                        else
                        {
                            TempData["Message"] = paytermlist.errordescription;
                        }
                        return RedirectToAction(nameof(LPOList));
                        //return RedirectToAction(nameof(Index));

                    }

                }
            }
            ViewData["error"] = response.Data.GatewayResponse;
            return RedirectToAction("Index");
            //return Json(new { redirectToUrl = Url.Action("LPOList", "Borrower") });
        }

        public IActionResult LPOList()
        {
            return View("LPOlist");
        }

        [HttpGet]
        public async Task<ActionResult> LPOlistData()
        {
            //LPOList paytermlist = new LPOList();
            var userID = HttpContext.Session.GetString("UserID");
            var j = Convert.ToInt32(userID);
            var userid = j.ToString();

            string nkey = GetIPAddress();
            using (var httpClient = new HttpClient())
            {
                var data = new Dictionary<string, string>
                {
                   //{ "NKEY", "AAADA2342323232332323" },
                   { "NKEY", nkey },
                   { "BORROWER_ID", userid },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(data);
                var lpoorderbyborrower = _configuration["lpoorderbyborrower"];
                using (var response = await httpClient.PostAsync(lpoorderbyborrower, content))
                {
                    List<LPO> taiwo = new List<LPO>();
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<LPOList>(apiResponse);
                    if (paytermlist.errorcode != null && paytermlist.errorcode == "-2000")
                    {
                        
                        var lpo = new LPO();
                        lpo.tokentimeout = true;
                        taiwo.Add(lpo);
                         return Json(new { data = taiwo.ToArray() });
                    }
                    else
                    {

                        
                        foreach (var obj in paytermlist.LPOs)
                        {
                            LPO lpo = new LPO();
                            lpo.country = obj.country;
                            lpo.BORROWER_COST = Convert.ToDecimal(obj.BORROWER_COST).ToString("N");
                            lpo.LPO_NUMBER = obj.LPO_NUMBER;
                            lpo.LPO_TOTAL_PRICE = Convert.ToDecimal(obj.LPO_TOTAL_PRICE).ToString("N");
                            lpo.InitialInvestment = Convert.ToDecimal(obj.INITIAL_INVESTMENT_BY_BORROWER).ToString("N");
                            lpo.NUMBER_DOCUMENTS_UPLOADED = obj.NUMBER_DOCUMENTS_UPLOADED;
                            lpo.tokentimeout = false;
                            taiwo.Add(lpo);

                        }
                        return Json(new { data = taiwo.ToArray() });
                    }
                }

            }

        }
        public static int Generate()
        {
            Random rand = new Random((int)DateTime.Now.Ticks);
            return rand.Next(100000000, 999999999);
        }

        public async Task<VALIDATE> ValidateFund(string Issuer, string ValueOfPO, string BorrowerCost, string DateInVestmentNeeded, string Country, string IssuerPayOnTime, string LpoNumber, string Suppliercompany, string Termmeasurement, string LPO_ITEMS, string initialinvestmentbyborrower, string LPODueDate, string Payterm, string userid)
        {

            string nkey = GetIPAddress();
            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "LPO_ISSUER_ID", Issuer },
                   { "VAL_OF_PO", ValueOfPO },
                   { "BORROWER_COST", BorrowerCost},
                   { "DATE_INV_NEEDED",DateInVestmentNeeded },
                   { "MATERIAL_SOURCE_COUNTRY_ID", Country },
                   { "ISSUER_PAY_ONTIME", IssuerPayOnTime },
                   { "LPO_NUMBER",LpoNumber },
                   { "LPO_SUPPLIER_COY_ID", Suppliercompany },
                   { "LPO_ITEM_MEASUREMENT_TYPE_ID", Termmeasurement },
                   { "LPO_ITEMS", LPO_ITEMS },
                   { "INITIAL_INVESTMENT_BY_BORROWER", initialinvestmentbyborrower },
                   { "LPO_DUE_DATE", LPODueDate },
                   { "LPO_ISSUER_PAYTERMS_ID", Payterm },
                   { "LPO_BORROWER_ID", userid },
                   { "STATUS", "A" },
                    //{ "NKEY", "AAADA2342323232332323" },
                    {"NKEY",nkey },
                   { "CHANNEL", "W" }
                };
                var content = new FormUrlEncodedContent(datacol);
                var validatelpoorderv4 = _configuration["validatelpoorderv4"];
                using (var response = await httpClient.PostAsync(validatelpoorderv4, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var valresult = JsonConvert.DeserializeObject<VALIDATE>(apiResponse);

                    //string valresultstring = valresult.ELIGIBILITY;
                    //return valresultstring;
                    return valresult;
                }

            }
        }

        [HttpGet]
        public async Task<IActionResult> DashBoard()
        {
            //var nkey = HttpContext.Session.GetString("nkey");
            var userID = HttpContext.Session.GetString("UserID");

            string nkey = GetIPAddress();
            var j = Convert.ToInt32(userID);
            var userid = j.ToString();
            DashBoardViewM dashboard = new DashBoardViewM();
            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "LPO_BORROWER_ID", userid },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);
                var borrowerdashboard = _configuration["borrowerdashboard"];
                using (var response = await httpClient.PostAsync(borrowerdashboard, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var paytermlist = JsonConvert.DeserializeObject<DashBoardVM>(apiResponse);
                    if (paytermlist.errorcode != null && paytermlist.errorcode=="-2000")
                    {
                        var eresponse = JsonConvert.DeserializeObject<ErrorResponse>(apiResponse);
                        if (eresponse.errorcode != null && eresponse.errorcode == "-2000")
                        {
                            //Log the user out
                            RedirectToAction("SignOutAsync", "Borrower", new { area = "Borrower" });
                        }
                    }
                    dashboard.DashBoardVM = paytermlist;
                }

            }
            return View(dashboard);
        }

        public async Task<IActionResult> PersonalView()
        {
            var BorrowersessionInfo = JsonConvert.DeserializeObject<ObjectSession>(HttpContext.Session.GetString("borrowersession"));

            var Email = BorrowersessionInfo.Email;
            //var Email = "gboladeshada@gmail.com";
            var Password = BorrowersessionInfo.Password;


            string nkey = GetIPAddress();
            PersonalInfoModel responsedes = new();
            using (var httpClient = new HttpClient())
            {
                var data = new Dictionary<string, string>
                {
                   { "NKEY", nkey },
                   { "EMAILADDRESS", Email },
                   { "xPASSWORD", Password },
                   { "TYPE_OF_ACTOR", "LPO_BORROWER" }
                };
                var content = new FormUrlEncodedContent(data);


                var loginwithemail = _configuration["loginwithemail"];
                using (var response = await httpClient.PostAsync(loginwithemail, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    responsedes = JsonConvert.DeserializeObject<PersonalInfoModel>(apiResponse);
                    //ViewComponent(typeof(PersonalViewComponent), responsedes);
                }

                //return RedirectToAction(nameof(Index));//uncomment this  //

            }
            //return  ViewComponent(typeof(PersonalViewComponent), responsedes);
            return View("PersonalInfo", responsedes);
        }

        public ActionResult ChangePassword()
        {
            return View();
        }

        [HttpPost]
        public async Task<JsonResult> SubmitChangePassword(ChangePasswordData changepassdata)
        {
            IHttpContextAccessor _httpContextAccessor = new HttpContextAccessor();
            var userID = _httpContextAccessor.HttpContext.Session.GetString("UserID");
            var j = Convert.ToInt32(userID);
            var userid = j.ToString();

            bool haserror = false;

            LPO lpo = new LPO();
            string oldpass = changepassdata.oldpass;
            string newpass = changepassdata.newpass;
            string confirmpass = changepassdata.confirmpass;


            string nkey = GetIPAddress();
            using (var httpClient = new HttpClient())
            {
                var datacol = new Dictionary<string, string>
                {
                   { "TYPE_OF_ACTOR","LPO_BORROWER"},
                   { "ID", userid },
                   { "OLDPASSWORD", oldpass },
                   { "NEWPASSWORD", newpass },
                   { "CONFIRMPASSWORD", confirmpass },
                   { "NKEY", nkey },
                   { "CHANNEL", "W" },
                };
                var content = new FormUrlEncodedContent(datacol);
                var changepassword = _configuration["changepassword"];
                using (var response = await httpClient.PostAsync(changepassword, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<ERROR>(apiResponse);
                    if (result.errorcode == "0")
                    {
                        haserror = false;
                        //return Json(new { redirectToUrl = Url.Action("Home", "Borrower", lpo) });
                    }
                    else
                    {
                        haserror = true;
                        //return Json(new { redirectToUrl = 0 });
                    }

                }

            }
            if (!haserror)
            {

                return Json(new { redirectToUrl = Url.Action("Home", "Borrower", lpo) });
            }
            else
            {

                return Json(new { redirectToUrl = "" });
            }


        }

        public string GetIPAddress()
        {
            var BorrowersessionInfo = JsonConvert.DeserializeObject<ObjectSession>(HttpContext.Session.GetString("borrowersession"));
            var Email = BorrowersessionInfo.Email;

            IPAddress remoteIpAddress = Request.HttpContext.Connection.RemoteIpAddress;
            string result = "";
            string result2 = "";
            if (remoteIpAddress != null)
            {
                // If we got an IPV6 address, then we need to ask the network for the IPV4 address 
                // This usually only happens when the browser is on the same machine as the server.
                if (remoteIpAddress.AddressFamily == System.Net.Sockets.AddressFamily.InterNetworkV6)
                {
                    remoteIpAddress = System.Net.Dns.GetHostEntry(remoteIpAddress).AddressList.First(x => x.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork);
                }
                result = remoteIpAddress.ToString();
            }
            var nkeyresult = HttpContext.Session.GetString("nkey");
            string MachineName1 = Environment.MachineName;
            result2 = Email + " " + "LPO_BORROWER" + " " + MachineName1 + " " + result + " " + nkeyresult;
            return result2;
        }

        public ActionResult Cancelredirect()
        {
            return RedirectToAction("Home", "Borrower", new { area = "Borrower" });
        }

        [HttpGet]
        public async Task<IEnumerable<SelectListItem>> LoadBank()
        {

            string nkey = GetIPAddress();
            //var contryList = new CountryResponse();
            using (var httpClient = new HttpClient())
            {

                var data = new Dictionary<string, string>
                {
                   { "COUNTRY_ID", "234" },
                   { "NKEY", nkey },
                   { "TYPE_OF_ACTOR", "LPO_ISSUER" }
                };
                var content = new FormUrlEncodedContent(data);


                LPO issuerss = new();
                var bankcodeurl = _configuration["bankcodeurl"];
                using (var response = await httpClient.PostAsync(bankcodeurl, content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    var banklists = JsonConvert.DeserializeObject<IList<BANKs>>(apiResponse);
                    if (apiResponse == null)
                    {
                        var eresponse = JsonConvert.DeserializeObject<ErrorResponse>(apiResponse);
                        if (eresponse.errorcode != null && eresponse.errorcode == "-2000")
                        {
                            //Log the user out
                            RedirectToAction("SignOutAsync", "Borrower", new { area = "Borrower" });
                        }
                    }
                    else
                    {
                        List<SelectListItem> lstselectListItem = new();
                        foreach (var banklist in banklists)
                        {
                            SelectListItem selectListItem2 = new SelectListItem()
                            {
                                Text = banklist.BankCodes.BANK_NAME,
                                Value = banklist.BankCodes.BANK_CODE + "_"+banklist.BankCodes.COUNTRY_ID,
                                //Selected = city.IsSelected
                            };
                            lstselectListItem.Add(selectListItem2);
                        }
                        issuerss.issuers = lstselectListItem;
                    }


                }
                return issuerss.issuers;

            }
        }
        public async Task<IActionResult> SignOutAsync()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

            HttpContext.Session.Remove("UserID");
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home", new { area = "" });
        }
    }
}
