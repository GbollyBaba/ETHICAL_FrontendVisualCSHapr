﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EthicalVendor.Areas.Borrower.Models
{
    public class LPOList
    {
        public IEnumerable<LPO> LPOs { get; set; }
        public string errorcode { get; set; }
    }

    public class ChangePasswordData
    {
        public string oldpass { get; set; }
        public string newpass { get; set; }
        public string confirmpass { get; set; }
    }
}
