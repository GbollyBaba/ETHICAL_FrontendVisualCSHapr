﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EthicalVendor.Areas.Borrower.Models
{
    public class LPO_ITEMS
    { 
        public string LPO_ITEM_MEASUREMENT_TYPE_ID { get; set; }
        public string LPO_ITEM_DESCRIPTION { get; set; }
        public int LPO_QUANTITY { get; set; }
        public int LPO_UNIT_PRICE { get; set; }
        public int LPO_TOTAL_PRICE { get; set; }
    }

   
}
