﻿using EthicalVendor.Utility;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace EthicalVendor.Areas.Borrower.Models
{

    public class LPO
    {
        public string LPO_ISSUER_ID { get; set; }

        public string ValueOfPO { get; set; }
        [JsonPropertyName("VAL_OF_PO")]
        public string VAL_OF_PO { get; set; }
        [Display(Name = "BORROWER COST")]
        //[Required]
        public string BorrowerCost { get; set; }
        [JsonPropertyName("BORROWER_COST")]
        public string BORROWER_COST { get; set; }
        [JsonPropertyName("DATE_INV_NEEDED")]
        public DateTime DATE_INV_NEEDED { get; set; }
        //[Required]
        public DateTime DateInVestmentNeeded { get; set; }
        public string MateriaSourceCountryID { get; set; }
        public string IssuerPayOnTime { get; set; }
        //[Required]
        public string LpoNumber { get; set; }
        [JsonPropertyName("LPO_NUMBER")]
        public string LPO_NUMBER { get; set; }
        public string LPOSupplierComapnyID { get; set; }
        [JsonPropertyName("LPO_ITEM_DESCRIPTION")]

        public string LPO_ITEM_DESCRIPTION { get; set; }
        //[Required]
        [Display(Name = "Item Description")]
        public string LPOItemDescription { get; set; }

        //[Required]
        //[Range(0, int.MaxValue, ErrorMessage = "The value must be greater than 0")]
        public int LPOQuantity { get; set; }
        [JsonPropertyName("LPO_QUANTITY")]
        public string LPO_QUANTITY { get; set; }
        //[Required]
        //[Range(0, int.MaxValue, ErrorMessage = "The value must be greater than 0")]
        public string LPOUnitPrice { get; set; }
        [JsonPropertyName("InitialInvestment")]
        public string InitialInvestment { get; set; }
        [JsonPropertyName("INITIAL_INVESTMENT_BY_BORROWER")]
        public string INITIAL_INVESTMENT_BY_BORROWER { get; set; }
        [JsonPropertyName("INVESTED_FUND_SOFAR")]
        public string INVESTED_FUND_SOFAR { get; set; }
        [JsonPropertyName("ISSUER_CONFIRMATION_REMARKS")]
        public string ISSUER_CONFIRMATION_REMARKS { get; set; }
        [JsonPropertyName("LPO_TOTAL_PRICE")]
        public string LPO_TOTAL_PRICE { get; set; }
        [JsonPropertyName("LPO_ORDER_ID")]
        public string LPO_ORDER_ID { get; set; }
        //[Required]
        public string LPOTotalPrice { get; set; }
        //[Required]
        public DateTime LPODueDate { get; set; }
        public char Status { get; set; }
        public string LPOBorrowerId { get; set; }
        public string Channel { get; set; }
        public string Nkey { get; set; }
        [Display(Name = "Issuer")]

        public string issuer { get; set; }
        public string country { get; set; }
        public string suppliercompany { get; set; }
        public string payterm { get; set; }
        public string termmeasurement { get; set; }
       
        public IEnumerable<SelectListItem> issuers { get; set; }

        public IEnumerable<SelectListItem> countries { get; set; }
        public IEnumerable<SelectListItem> suppliercompanies { get; set; }
        public IEnumerable<SelectListItem> payterms { get; set; }
        public IEnumerable<SelectListItem> termmeasurements { get; set; }

        public LPOList LPOs { get; private set; }

        //File Part
        public string docURL { get; set; }

        //[Required(ErrorMessage = "Please select a file.")]
        //[DataType(DataType.Upload)]
        //[MaxFileSize(5 * 1024)]  //this is 5MB
        //[AllowedExtensions(new string[] { ".pdf"})]
        public virtual IFormFile docFile{get; set;}
        public string docStorageName { get; set; }

        public IEnumerable<LPO_ITEMS> LPO_ITEMS { get; set; }
        [JsonPropertyName("NUMBER_DOCUMENTS_UPLOADED")]
        public string NUMBER_DOCUMENTS_UPLOADED { get; set; }

        public bool tokentimeout { get; set; }  
    }
      
    
}
