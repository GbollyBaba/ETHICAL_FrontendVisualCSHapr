﻿using EthicalVendor.Models;
using EthicalVendor.Models.ViewModels;
using EthicalVendor.Utility;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Threading.Tasks;

namespace EthicalVendor.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

         

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        
        public IActionResult AboutUs()
        {
            return View();
        }

        public IActionResult Faq()
        {
            return View();
        }

        public async Task<IActionResult> SignIn(Auth auth)
        {
            using (var httpClient = new HttpClient())
            {
                var data = new Dictionary<string, string>
                {
                   { "NKEY", "AAAA" },
                   { "EMAILADDRESS", auth.Email },
                   { "xPASSWORD", auth.Password },
                   { "TYPE_OF_ACTOR", auth.UserType }
                };
                var content = new FormUrlEncodedContent(data);

                
                Response responsedes = new();
                //using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/EthSol_LoginWithEmail", content))
                using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/EthSol_LoginWithEmail", content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    responsedes = JsonConvert.DeserializeObject<Response>(apiResponse);
                    if(responsedes.errorcode=="0" && responsedes.STATUS =="A")//is successfully login
                    {
                        var nkey = responsedes.nkey;
                        HttpContext.Session.SetString("nkey", nkey);   
                        
                        if (auth.UserType == "LPO_BORROWER")
                        {
                            var j = Convert.ToInt32(responsedes.LPO_BORROWER_ID.Trim());
                            
                            HttpContext.Session.SetObject("UserID", j);

                            ObjectSession supplierSession = new ObjectSession()
                            {
                                Email = responsedes.EMAILADDRESS,
                                suppliertype = "p",
                                Password = auth.Password
                            };
                            HttpContext.Session.SetString("borrowersession", JsonConvert.SerializeObject(supplierSession));

                            //TempData[FinanceUtility.Success] = "Successfully Sign in as Borrower"; //Flash Notification
                            //Create Cookie for the user here
                            var claims = new[] { new Claim(ClaimTypes.Name, responsedes.FIRSTNAME),
                             new Claim(ClaimTypes.Role, "Borrower"),
                             new Claim(ClaimTypes.Email,responsedes.EMAILADDRESS)};
                            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                            await HttpContext.SignInAsync(
                                   CookieAuthenticationDefaults.AuthenticationScheme,
                                   new ClaimsPrincipal(identity));
                            return RedirectToAction("Home", "Borrower", new { area = "Borrower" });
                        }
                        else if (auth.UserType == "LPO_ISSUER")
                        {
                            ObjectSession supplierSession = new ObjectSession()
                            {
                                Email = responsedes.EMAILADDRESS,
                                Password = auth.Password
                            };
                            HttpContext.Session.SetString("issuersession", JsonConvert.SerializeObject(supplierSession));

                            var k = Convert.ToInt32(responsedes.LPO_ISSUER_ID.Trim());
                            HttpContext.Session.SetObject("UserID", k);
                            //Create Cookie for the user here
                            var claims = new[] { new Claim(ClaimTypes.Name, responsedes.FIRSTNAME),
                             new Claim(ClaimTypes.Role, "Issuer"),
                             new Claim(ClaimTypes.Email,responsedes.EMAILADDRESS)};
                            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                            await HttpContext.SignInAsync(
                                   CookieAuthenticationDefaults.AuthenticationScheme,
                                   new ClaimsPrincipal(identity));
                            return RedirectToAction("Home", "Issuers", new { area = "Issuers" });
                        }
                        else if (auth.UserType == "LPO_INVESTOR")
                        {
                            ObjectSession supplierSession = new ObjectSession()
                            {
                                Email = responsedes.EMAILADDRESS,
                                suppliertype = "p",
                                Password = auth.Password
                            };
                            HttpContext.Session.SetString("investorsession", JsonConvert.SerializeObject(supplierSession));
                            var l = Convert.ToInt32(responsedes.LPO_INVESTOR_ID.Trim());
                            HttpContext.Session.SetObject("UserID", l);
                            HttpContext.Session.SetObject("Email",responsedes.EMAILADDRESS);
                            HttpContext.Session.SetObject("InvestorType", "P");
                            //Create Cookie for the user here
                            var claims = new[] { new Claim(ClaimTypes.Name, responsedes.FIRSTNAME),
                             new Claim(ClaimTypes.Role, "Investor"),
                             new Claim(ClaimTypes.Email,responsedes.EMAILADDRESS)};
                            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                            await HttpContext.SignInAsync(
                                   CookieAuthenticationDefaults.AuthenticationScheme,
                                   new ClaimsPrincipal(identity));

                            return RedirectToAction("Index", "Investor", new { area = "Investor" });
                        }
                        else if (auth.UserType == "LPO_INVESTOR_COY")
                        {
                            ObjectSession supplierSession = new ObjectSession()
                            {
                                Email = responsedes.EMAILADDRESS,
                                suppliertype = "C",
                                Password = auth.Password
                            };
                            HttpContext.Session.SetString("investorsession", JsonConvert.SerializeObject(supplierSession));
                            //var l = Convert.ToInt32(responsedes.LPO_INVESTOR_ID.Trim()); 
                            var l = Convert.ToInt32(responsedes.LPO_INVESTOR_COY_ID.Trim());
                            HttpContext.Session.SetObject("UserID", l);
                            HttpContext.Session.SetObject("Email", responsedes.EMAILADDRESS);
                            HttpContext.Session.SetObject("InvestorType", "C");
                            //Create Cookie for the user here
                            var claims = new[] { new Claim(ClaimTypes.Name, responsedes.FIRSTNAME),
                             new Claim(ClaimTypes.Role, "Investor"),
                             new Claim(ClaimTypes.Email,responsedes.EMAILADDRESS)};
                            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                            await HttpContext.SignInAsync(
                                   CookieAuthenticationDefaults.AuthenticationScheme,
                                   new ClaimsPrincipal(identity));

                            return RedirectToAction("Index", "Investor", new { area = "Investor" });
                        }
                        else if (auth.UserType == "LPO_SUPPLIER_COY")//Merchant
                        {
                            ObjectSession supplierSession = new ObjectSession()
                            {
                                Email = responsedes.EMAILADDRESS,
                               Password = auth.Password
                            };
                            HttpContext.Session.SetString("supliersession", JsonConvert.SerializeObject(supplierSession));
                            var l = Convert.ToInt32(responsedes.LPO_SUPPLIER_COY_ID.Trim());
                            HttpContext.Session.SetObject("UserID", l);
                            //Create Cookie for the user here
                            var claims = new[] { new Claim(ClaimTypes.Name, responsedes.FIRSTNAME),
                             new Claim(ClaimTypes.Role, "Supplier"),
                             new Claim(ClaimTypes.Email,responsedes.EMAILADDRESS)};
                            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                            await HttpContext.SignInAsync(
                                   CookieAuthenticationDefaults.AuthenticationScheme,
                                   new ClaimsPrincipal(identity));

                            return RedirectToAction("Index", "Merchant", new { area = "Merchant" });
                        }
                    }
                    else if(responsedes.errorcode == "20" && responsedes.STATUS == "I") // Has SignUp but yet to Validate Profile
                    {
                        

                        responsedes = JsonConvert.DeserializeObject<Response>(apiResponse);
                        responsedes.UserType = responsedes.TYPE_OF_ACTOR;
                        var nkey = responsedes.nkey;
                        HttpContext.Session.SetString("nkey", nkey);

                        if (responsedes.TYPE_OF_ACTOR =="LPO_BORROWER")
                        {
                            responsedes.ID = responsedes.LPO_BORROWER_ID;
                        }
                        else if (responsedes.TYPE_OF_ACTOR == "LPO_INVESTOR")
                        {
                            responsedes.ID = responsedes.LPO_INVESTOR_ID;
                        }
                        else if (responsedes.TYPE_OF_ACTOR == "LPO_ISSUER")
                        {
                            responsedes.ID = responsedes.LPO_ISSUER_ID;
                        }
                        var convertedJson = JsonConvert.SerializeObject(responsedes);
                        TempData["tokenRev"] = convertedJson;
                        return RedirectToAction(nameof(ValidateProfile), "Home");
                    }

                }
                TempData[FinanceUtility.Success] = "Error In Signin";
                //return RedirectToAction("Home", "Issuers", new { area = "Issuers" });//Remove this ,when Shada amend the login
                return RedirectToAction(nameof(Index));//uncomment this 

            }
           
        }

        public async Task<IActionResult> SignUp()
        {
            var contryList = new CountryResponse();
            using (var httpClient = new HttpClient())
            {
                var data = new Dictionary<string, string>
                {
                   { "NKEY", "AAAAAA" },
                   { "CHANNEL", "1" }
                };
                var content = new FormUrlEncodedContent(data);

                CountryData countrydata = new CountryData();

                using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/Eth_Sol_Get_Country", content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    CountryData countrylist = JsonConvert.DeserializeObject<CountryData>(apiResponse);
                    List<SelectListItem> lstselectListItem = new List<SelectListItem>();

                    foreach (var country in countrylist.COUNTRIES)
                    {
                        SelectListItem selectListItem = new SelectListItem()
                        {
                            Text = country.COUNTRY,
                            Value = country.COUNTRY_ID,
                            //Selected = city.IsSelected
                        };
                        lstselectListItem.Add(selectListItem);
                    }
                    countrydata.countries = lstselectListItem;
                }
                return View(countrydata);
            }
        }

        public async Task<IActionResult> SignUp2()
        {
            var contryList = new CountryResponse();
            using (var httpClient = new HttpClient())
            {
                var data = new Dictionary<string, string>
                {
                   { "NKEY", "AAAAAA" },
                   { "CHANNEL", "1" }
                };
                var content = new FormUrlEncodedContent(data);

                SignUp signup = new SignUp();

                using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/Eth_Sol_Get_Country", content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    SignUp countrylist = JsonConvert.DeserializeObject<SignUp>(apiResponse);
                    List<SelectListItem> lstselectListItem = new List<SelectListItem>();

                    foreach (var country in countrylist.COUNTRIES)
                    {
                        SelectListItem selectListItem = new SelectListItem()
                        {
                            Text = country.COUNTRY,
                            Value = country.COUNTRY_ID,
                            //Selected = city.IsSelected
                        };
                        lstselectListItem.Add(selectListItem);
                    }
                    signup.countries = lstselectListItem;
                }
                return View(signup);
            }
        }

        public async Task<IActionResult> SignOutAsync()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

            return RedirectToAction("Index");
        }
        public IActionResult ForgetPassword()
        {
            return View(); 
        }
        [HttpPost]
        public async Task<IActionResult> ForgetPassword(ForgetPassword person)
        {
            if(ModelState.IsValid)
            {
                if(person != null)
                {
                    using (var httpClient = new HttpClient())
                    {
                        var data = new Dictionary<string, string>
                        {
                           { "NKEY", "AAAA" },
                           { "CHANNEL", "W" },
                           { "TYPE_OF_ACTOR", person.TYPE_OF_ACTOR },
                           { "EMAILADDRESS", person.EMAILADDRESS }
                           /*{ "FIRSTNAME", person.FIRSTNAME },
                           { "SURNAME", person.LASTNAME },
                           { "MOBILENUMBER", person.MOBILENUMBER },*/
                        };
                        var content = new FormUrlEncodedContent(data);


                        Response responsedes = new();
                        using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/EthSol_ForgotPasswordWithEmail", content))
                        {
                            string apiResponse = await response.Content.ReadAsStringAsync();
                            responsedes = JsonConvert.DeserializeObject<Response>(apiResponse);
                            if (responsedes.errorcode == "0")//is successfully login
                            {
                                TempData[FinanceUtility.Success] = "Account password has been changed successfully! Please check your mail for further action";
                                
                                return RedirectToAction(nameof(Index));
                            }
                            

                        }
                        TempData[FinanceUtility.Error] = "Something went wrong, please try again later";
                       
                        return RedirectToAction(nameof(Index));//uncomment this 

                    }

                }
                return View();//Take The user to sign up page
            }
            //Person person = new Person();
            return View(person);
        }

        [HttpGet]
        public async Task<JsonResult> LoadState(string countryid)
        {
            //var contryList = new CountryResponse();
            using (var httpClient = new HttpClient())
            {
                var data = new Dictionary<string, string>
                {
                   { "NKEY", "AAAAAA" },
                   { "CHANNEL", "1" },
                    {"COUNTRY_ID", countryid}
                };
                var content = new FormUrlEncodedContent(data);

                CountryData countrydata = new CountryData();

                using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/Eth_Sol_Get_State", content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    CountryData statelist = JsonConvert.DeserializeObject<CountryData>(apiResponse);
                    List<SelectListItem> lstselectListItem = new List<SelectListItem>();
                   
                    foreach (var state in statelist.STATEs)
                    {
                        SelectListItem selectListItem2 = new SelectListItem()
                        {
                            Text = state.STATE,
                            Value = state.STATE_ID,
                            //Selected = city.IsSelected
                        };
                        lstselectListItem.Add(selectListItem2);
                    }
                    countrydata.states = lstselectListItem;
                }
                return Json(new SelectList(countrydata.states, "Value", "Text"));
                //return View("SignUp",countrydata);
            }
        }

        [HttpGet]
        public async Task<JsonResult> LoadLga(string stateid)
        {
            //var contryList = new CountryResponse();
            using (var httpClient = new HttpClient())
            {
                var data = new Dictionary<string, string>
                {
                   { "NKEY", "AAAAAA" },
                   { "CHANNEL", "1" },
                    {"STATE_ID", stateid}
                };
                var content = new FormUrlEncodedContent(data);

                CountryData countrydata = new CountryData();

                using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/Eth_Sol_Get_Lga", content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    CountryData lgalist = JsonConvert.DeserializeObject<CountryData>(apiResponse);
                    List<SelectListItem> lstselectListItem = new List<SelectListItem>();

                    foreach (var lga in lgalist.LGAs)
                    {
                        SelectListItem selectListItem2 = new SelectListItem()
                        {
                            Text = lga.LGA,
                            Value = lga.LGA_ID,
                            //Selected = city.IsSelected
                        };
                        lstselectListItem.Add(selectListItem2);
                    }
                    countrydata.lgas = lstselectListItem;
                }
                return Json(new SelectList(countrydata.lgas, "Value", "Text"));
                //return View("SignUp",countrydata);
            }
        }

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        public async Task<IActionResult> OnBorrower(CountryData borrower)
        {
            if (ModelState.IsValid)
            {
                if (borrower.UserType == "LPO_BORROWER")
                {
                    using (var httpClient = new HttpClient())
                    {
                        var data = new Dictionary<string, string>
                    {
                       { "FIRSTNAME", borrower.Person.FIRSTNAME },
                       { "SURNAME", borrower.Person.LASTNAME },
                       { "MIDDLENAME", borrower.Person.MIDDLENAME},
                       { "BIRTHDATE", borrower.Person.BIRTHDATE.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "STREET1", borrower.Address.STREET1 },
                       { "STREET2", borrower.Address.STREET2 },
                       { "MOBILENUMBER", borrower.Person.MOBILENUMBER },
                       { "LGA_ID", borrower.lga },
                       { "STATE_ID", borrower.state },
                       { "COUNTRY_ID", borrower.country },
                       { "MARITAL_STATUS", borrower.Person.MaritalStatus },
                       { "MACADDRESS", "AAAAAA" },
                       { "EMAILADDRESS", borrower.Person.EMAILADDRESS},
                       { "PASSWORD", borrower.Person.PASSWORD },
                       { "CONFIRMPASSWORD", borrower.Person.PASSWORD },
                       { "CUSTOMER_CLASSIFICATION", "AAAAAA" },
                       { "TOKEN", "1111" },
                       { "LOGINCOUNT", "0" },
                       { "STATUS", "I" },
                       { "COMPANY_NAME", borrower.Address.COMPANY_NAME },
                       { "COMPANY_REG_NO", borrower.Address.COMPANY_REG_NO },
                       { "DATE_REG_WITH_ISSUER",  DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "NKEY", "AAAAAA" },
                       { "CHANNEL", "W" }
                    };

                        var content = new FormUrlEncodedContent(data);

                        CountryData countrydata = new CountryData();
                        Response responsedes = new();
                        using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/EthSol_Borrower", content))
                        {

                            string apiResponse = await response.Content.ReadAsStringAsync();

                            responsedes = JsonConvert.DeserializeObject<Response>(apiResponse);
                            responsedes.UserType = borrower.UserType;

                            var convertedJson = JsonConvert.SerializeObject(responsedes);
                            TempData[FinanceUtility.Success] = "Successfully Sign Up";
                            TempData["tokenRev"] = convertedJson;
                        }


                    }
                }
                else if (borrower.UserType == "LPO_SUPPLIER_COY")
                {
                    using (var httpClient = new HttpClient())
                    {
                        var data = new Dictionary<string, string>
                    {
                       { "FIRSTNAME", borrower.Person.FIRSTNAME },
                       { "SURNAME", borrower.Person.LASTNAME },
                       { "MIDDLENAME", borrower.Person.MIDDLENAME},
                       { "BIRTHDATE", borrower.Person.BIRTHDATE.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "STREET1", borrower.Address.STREET1 },
                       { "STREET2", borrower.Address.STREET2 },
                       { "MOBILENUMBER", borrower.Person.MOBILENUMBER },
                       { "LGA_ID", borrower.lga },
                       { "STATE_ID", borrower.state },
                       { "COUNTRY_ID", borrower.country },
                       { "MARITAL_STATUS", borrower.Person.MaritalStatus },
                       { "MACADDRESS", "AAAAAA" },
                       { "EMAILADDRESS", borrower.Person.EMAILADDRESS},
                       { "PASSWORD", borrower.Person.PASSWORD },
                       { "CONFIRMPASSWORD", borrower.Person.PASSWORD },
                       { "CUSTOMER_CLASSIFICATION", "HIGH" },
                       { "TOKEN", "1111" },
                       { "LOGINCOUNT", "0" },
                       { "STATUS", "I" },
                       { "COY_NAME", borrower.Address.COMPANY_NAME },
                       { "COY_REG_NO", borrower.Address.COMPANY_REG_NO },
                       { "COY_MOBILENUMBER", borrower.Address.COMPANY_Mobile },
                       { "COY_EMAILADRESS", borrower.Address.COMPANY_Email },
                       { "COY_WEBSITE", borrower.Address.COMPANY_Website },
                       { "DATE_REG_WITH_ISSUER",  DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "NKEY", "1423232" },
                       { "CHANNEL", "W" }
                    };

                        var content = new FormUrlEncodedContent(data);

                        CountryData countrydata = new CountryData();
                        Response responsedes = new();
                        using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/EthSol_Supplier_Coy", content))
                        {

                            string apiResponse = await response.Content.ReadAsStringAsync();

                            responsedes = JsonConvert.DeserializeObject<Response>(apiResponse);
                            responsedes.UserType = borrower.UserType;

                            var convertedJson = JsonConvert.SerializeObject(responsedes);

                            TempData["tokenRev"] = convertedJson;
                        }


                    }
                }
                else if (borrower.UserType == "LPO_ISSUER")
                {
                    using (var httpClient = new HttpClient())
                    {
                        var data = new Dictionary<string, string>
                    {
                       { "FIRSTNAME", borrower.Person.FIRSTNAME },
                       { "SURNAME", borrower.Person.LASTNAME },
                       { "MIDDLENAME", borrower.Person.MIDDLENAME},
                       { "BIRTHDATE", borrower.Person.BIRTHDATE.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "STREET1", borrower.Address.STREET1 },
                       { "STREET2", borrower.Address.STREET2 },
                       { "MOBILENUMBER", borrower.Person.MOBILENUMBER },
                       { "LGA_ID", borrower.lga },
                       { "STATE_ID", borrower.state },
                       { "COUNTRY_ID", borrower.country },
                       { "MARITAL_STATUS", borrower.Person.MaritalStatus },
                       { "MACADDRESS", "AAAAAA" },
                       { "EMAILADDRESS", borrower.Person.EMAILADDRESS},
                       { "PASSWORD", borrower.Person.PASSWORD },
                       { "CONFIRMPASSWORD", borrower.Person.PASSWORD },
                       { "CUSTOMER_CLASSIFICATION", "HIGH" },
                       { "TOKEN", "1111" },
                       { "LOGINCOUNT", "0" },
                       { "STATUS", "I" },
                       { "COY_NAME", borrower.Address.COMPANY_NAME },
                       { "COY_REG_NO", borrower.Address.COMPANY_REG_NO },
                       { "COY_MOBILENUMBER", borrower.Address.COMPANY_Mobile },
                       { "COY_EMAILADRESS", borrower.Address.COMPANY_Email },
                       { "COY_WEBSITE", borrower.Address.COMPANY_Website },
                       { "DATE_REG_WITH_ISSUER",  DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "NKEY", "1423232" },
                       { "CHANNEL", "W" }
                    };

                        var content = new FormUrlEncodedContent(data);

                        CountryData countrydata = new CountryData();
                        Response responsedes = new();
                        using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/EthSol_Issuer", content))
                        {

                            string apiResponse = await response.Content.ReadAsStringAsync();

                            responsedes = JsonConvert.DeserializeObject<Response>(apiResponse);
                            responsedes.UserType = borrower.UserType;

                            var convertedJson = JsonConvert.SerializeObject(responsedes);
                            TempData[FinanceUtility.Success] = "Successfully Sign Up as Issuer";
                            TempData["tokenRev"] = convertedJson;
                        }


                    }
                }
                else if (borrower.UserType == "LPO_INVESTOR_COY")
                {
                    using (var httpClient = new HttpClient())
                    {
                        var data = new Dictionary<string, string>
                    {
                       { "FIRSTNAME", borrower.Person.FIRSTNAME },
                       { "SURNAME", borrower.Person.LASTNAME },
                       { "MIDDLENAME", borrower.Person.MIDDLENAME},
                       { "BIRTHDATE", borrower.Person.BIRTHDATE.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "STREET1", borrower.Address.STREET1 },
                       { "STREET2", borrower.Address.STREET2 },
                       { "MOBILENUMBER", borrower.Person.MOBILENUMBER },
                       { "LGA_ID", borrower.lga },
                       { "STATE_ID", borrower.state },
                       { "COUNTRY_ID", borrower.country },
                       { "MARITAL_STATUS", borrower.Person.MaritalStatus },
                       { "MACADDRESS", "AAAAAA" },
                       { "EMAILADDRESS", borrower.Person.EMAILADDRESS},
                       { "PASSWORD", borrower.Person.PASSWORD },
                       { "CONFIRMPASSWORD", borrower.Person.PASSWORD },
                       { "CUSTOMER_CLASSIFICATION", "HIGH" },
                       { "TOKEN", "1111" },
                       { "LOGINCOUNT", "0" },
                       { "STATUS", "I" },
                       { "COY_NAME", borrower.Address.COMPANY_NAME },
                       { "COY_REG_NO", borrower.Address.COMPANY_REG_NO },
                       { "COY_MOBILENUMBER", borrower.Address.COMPANY_Mobile },
                       { "COY_EMAILADRESS", borrower.Address.COMPANY_Email },
                       { "COY_WEBSITE", borrower.Address.COMPANY_Website },
                       { "DATE_REG_WITH_ISSUER",  DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "NKEY", "1423232" },
                       { "CHANNEL", "W" }
                    };

                        var content = new FormUrlEncodedContent(data);

                        CountryData countrydata = new CountryData();
                        Response responsedes = new();
                        using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/EthSol_Investor_Coy", content))
                        {

                            string apiResponse = await response.Content.ReadAsStringAsync();

                            responsedes = JsonConvert.DeserializeObject<Response>(apiResponse);
                            responsedes.UserType = borrower.UserType;

                            var convertedJson = JsonConvert.SerializeObject(responsedes);
                            TempData[FinanceUtility.Success] = "Sign Up Successfully";
                            TempData["tokenRev"] = convertedJson;
                        }


                    }
                }
                else if (borrower.UserType == "LPO_INVESTOR")
                {
                    using (var httpClient = new HttpClient())
                    {
                        var data = new Dictionary<string, string>
                    {
                       { "FIRSTNAME", borrower.Person.FIRSTNAME },
                       { "SURNAME", borrower.Person.LASTNAME },
                       { "MIDDLENAME", borrower.Person.MIDDLENAME},
                       { "BIRTHDATE", borrower.Person.BIRTHDATE.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "STREET1", borrower.Address.STREET1 },
                       { "STREET2", borrower.Address.STREET2 },
                       { "MOBILENUMBER", borrower.Person.MOBILENUMBER },
                       { "LGA_ID", borrower.lga },
                       { "STATE_ID", borrower.state },
                       { "COUNTRY_ID", borrower.country },
                       { "MARITAL_STATUS", borrower.Person.MaritalStatus },
                       { "MACADDRESS", "AAAAAA" },
                       { "EMAILADDRESS", borrower.Person.EMAILADDRESS},
                       { "PASSWORD", borrower.Person.PASSWORD },
                       { "CONFIRMPASSWORD", borrower.Person.PASSWORD },
                       { "CUSTOMER_CLASSIFICATION", "HIGH" },
                       { "TOKEN", "1111" },
                       { "LOGINCOUNT", "0" },
                       { "STATUS", "I" },
                       { "COMPANY_NAME", borrower.Address.COMPANY_NAME },
                       { "COMPANY_REG_NO", borrower.Address.COMPANY_REG_NO },
                       { "DATE_REG_WITH_ISSUER",  DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "NKEY", "1423232" },
                       { "CHANNEL", "W" }
                    };

                        var content = new FormUrlEncodedContent(data);

                        CountryData countrydata = new CountryData();
                        Response responsedes = new();
                        using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/EthSol_Investor", content))
                        {

                            string apiResponse = await response.Content.ReadAsStringAsync();

                            responsedes = JsonConvert.DeserializeObject<Response>(apiResponse);
                            responsedes.UserType = borrower.UserType;

                            var convertedJson = JsonConvert.SerializeObject(responsedes);
                            TempData[FinanceUtility.Success] = "Sign Up Successfully";
                            TempData["tokenRev"] = convertedJson;
                        }


                    }
                }

                return RedirectToAction(nameof(ValidateProfile), "Home");
            }
            return RedirectToPage("SignUp");
        }

        public async Task<IActionResult> OnBorrower2(SignUp signup)
        {
            if (ModelState.IsValid)
            {
                if (signup.UserType == "LPO_BORROWER")
                {
                    using (var httpClient = new HttpClient())
                    {
                        var data = new Dictionary<string, string>
                    {
                       { "FIRSTNAME", signup.FIRSTNAME },
                       { "SURNAME", signup.LASTNAME },
                       { "MIDDLENAME", signup.MIDDLENAME},
                       { "BIRTHDATE", signup.BIRTHDATE.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "STREET1", signup.STREET1 },
                       { "STREET2", signup.STREET2 },
                       { "MOBILENUMBER", signup.MOBILENUMBER },
                       { "LGA_ID", signup.lga },
                       { "STATE_ID", signup.state },
                       { "COUNTRY_ID", signup.country },
                       { "MARITAL_STATUS", signup.MaritalStatus },
                       { "MACADDRESS", "AAAAAA" },
                       { "EMAILADDRESS", signup.EMAILADDRESS},
                       { "PASSWORD", signup.PASSWORD },
                       { "CONFIRMPASSWORD", signup.PASSWORD },
                       { "CUSTOMER_CLASSIFICATION", "AAAAAA" },
                       { "TOKEN", "1111" },
                       { "LOGINCOUNT", "0" },
                       { "STATUS", "I" },
                       { "COMPANY_NAME", signup.COMPANY_NAME },
                       { "COMPANY_REG_NO", signup.COMPANY_REG_NO },
                       { "DATE_REG_WITH_ISSUER",  DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "NKEY", "AAAAAA" },
                       { "CHANNEL", "W" }
                    };

                        var content = new FormUrlEncodedContent(data);


                        Response responsedes = new();
                        using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/EthSol_Borrower", content))
                        {

                            string apiResponse = await response.Content.ReadAsStringAsync();

                            responsedes = JsonConvert.DeserializeObject<Response>(apiResponse);
                            responsedes.UserType = signup.UserType;

                            var convertedJson = JsonConvert.SerializeObject(responsedes);
                            TempData[FinanceUtility.Success] = "Successfully Sign Up";
                            TempData["tokenRev"] = convertedJson;
                        }


                    }
                }
                else if (signup.UserType == "LPO_SUPPLIER_COY")
                {
                    using (var httpClient = new HttpClient())
                    {
                        var data = new Dictionary<string, string>
                    {
                       { "FIRSTNAME", signup.FIRSTNAME },
                       { "SURNAME", signup.LASTNAME },
                       { "MIDDLENAME", signup.MIDDLENAME},
                       { "BIRTHDATE", signup.BIRTHDATE.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "STREET1", signup.STREET1 },
                       { "STREET2", signup.STREET2 },
                       { "MOBILENUMBER", signup.MOBILENUMBER },
                       { "LGA_ID", signup.lga },
                       { "STATE_ID", signup.state },
                       { "COUNTRY_ID", signup.country },
                       { "MARITAL_STATUS", signup.MaritalStatus },
                       { "MACADDRESS", "AAAAAA" },
                       { "EMAILADDRESS", signup.EMAILADDRESS},
                       { "PASSWORD", signup.PASSWORD },
                       { "CONFIRMPASSWORD", signup.PASSWORD },
                       { "CUSTOMER_CLASSIFICATION", "HIGH" },
                       { "TOKEN", "1111" },
                       { "LOGINCOUNT", "0" },
                       { "STATUS", "I" },
                       { "COY_NAME", signup.COMPANY_NAME },
                       { "COY_REG_NO", signup.COMPANY_REG_NO },
                       { "COY_MOBILENUMBER", signup.COMPANY_Mobile },
                       { "COY_EMAILADRESS", signup.COMPANY_Email },
                       { "COY_WEBSITE", signup.COMPANY_Website },
                       { "DATE_REG_WITH_ISSUER",  DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "NKEY", "1423232" },
                       { "CHANNEL", "W" }
                    };

                        var content = new FormUrlEncodedContent(data);


                        Response responsedes = new();
                        using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/EthSol_Supplier_Coy", content))
                        {

                            string apiResponse = await response.Content.ReadAsStringAsync();

                            responsedes = JsonConvert.DeserializeObject<Response>(apiResponse);
                            responsedes.UserType = signup.UserType;

                            var convertedJson = JsonConvert.SerializeObject(responsedes);

                            TempData["tokenRev"] = convertedJson;
                        }


                    }
                }
                else if (signup.UserType == "LPO_ISSUER")
                {
                    using (var httpClient = new HttpClient())
                    {
                        var data = new Dictionary<string, string>
                    {
                       { "FIRSTNAME",signup.FIRSTNAME },
                       { "SURNAME", signup.LASTNAME },
                       { "MIDDLENAME", signup.MIDDLENAME},
                       { "BIRTHDATE", signup.BIRTHDATE.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "STREET1", signup.STREET1 },
                       { "STREET2", signup.STREET2 },
                       { "MOBILENUMBER", signup.MOBILENUMBER },
                       { "LGA_ID", signup.lga },
                       { "STATE_ID", signup.state },
                       { "COUNTRY_ID", signup.country },
                       { "MARITAL_STATUS", signup.MaritalStatus },
                       { "MACADDRESS", "AAAAAA" },
                       { "EMAILADDRESS", signup.EMAILADDRESS},
                       { "PASSWORD", signup.PASSWORD },
                       { "CONFIRMPASSWORD", signup.PASSWORD },
                       { "CUSTOMER_CLASSIFICATION", "HIGH" },
                       { "TOKEN", "1111" },
                       { "LOGINCOUNT", "0" },
                       { "STATUS", "I" },
                       { "COY_NAME", signup.COMPANY_NAME },
                       { "COY_REG_NO", signup.COMPANY_REG_NO },
                       { "COY_MOBILENUMBER", signup.COMPANY_Mobile },
                       { "COY_EMAILADRESS", signup.COMPANY_Email },
                       { "COY_WEBSITE", signup.COMPANY_Website },
                       { "DATE_REG_WITH_ISSUER",  DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "NKEY", "1423232" },
                       { "CHANNEL", "W" }
                    };

                        var content = new FormUrlEncodedContent(data);


                        Response responsedes = new();
                        using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/EthSol_Issuer", content))
                        {

                            string apiResponse = await response.Content.ReadAsStringAsync();

                            responsedes = JsonConvert.DeserializeObject<Response>(apiResponse);
                            responsedes.UserType = signup.UserType;

                            var convertedJson = JsonConvert.SerializeObject(responsedes);
                            TempData[FinanceUtility.Success] = "Successfully Sign Up as Issuer";
                            TempData["tokenRev"] = convertedJson;
                        }


                    }
                }
                else if (signup.UserType == "LPO_INVESTOR_COY")
                {
                    using (var httpClient = new HttpClient())
                    {
                        var data = new Dictionary<string, string>
                    {
                       { "FIRSTNAME", signup.FIRSTNAME },
                       { "SURNAME", signup.LASTNAME },
                       { "MIDDLENAME", signup.MIDDLENAME},
                       { "BIRTHDATE", signup.BIRTHDATE.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "STREET1", signup.STREET1 },
                       { "STREET2", signup.STREET2 },
                       { "MOBILENUMBER", signup.MOBILENUMBER },
                       { "LGA_ID", signup.lga },
                       { "STATE_ID", signup.state },
                       { "COUNTRY_ID", signup.country },
                       { "MARITAL_STATUS", signup.MaritalStatus },
                       { "MACADDRESS", "AAAAAA" },
                       { "EMAILADDRESS", signup.EMAILADDRESS},
                       { "PASSWORD", signup.PASSWORD },
                       { "CONFIRMPASSWORD", signup.PASSWORD },
                       { "CUSTOMER_CLASSIFICATION", "HIGH" },
                       { "TOKEN", "1111" },
                       { "LOGINCOUNT", "0" },
                       { "STATUS", "I" },
                       { "COY_NAME", signup.COMPANY_NAME },
                       { "COY_REG_NO", signup.COMPANY_REG_NO },
                       { "COY_MOBILENUMBER", signup.COMPANY_Mobile },
                       { "COY_EMAILADRESS", signup.COMPANY_Email },
                       { "COY_WEBSITE", signup.COMPANY_Website },
                       { "DATE_REG_WITH_ISSUER",  DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "NKEY", "1423232" },
                       { "CHANNEL", "W" }
                    };

                        var content = new FormUrlEncodedContent(data);


                        Response responsedes = new();
                        using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/EthSol_Investor_Coy", content))
                        {

                            string apiResponse = await response.Content.ReadAsStringAsync();

                            responsedes = JsonConvert.DeserializeObject<Response>(apiResponse);
                            responsedes.UserType = signup.UserType;

                            var convertedJson = JsonConvert.SerializeObject(responsedes);
                            TempData[FinanceUtility.Success] = "Sign Up Successfully";
                            TempData["tokenRev"] = convertedJson;
                        }


                    }
                }
                else if (signup.UserType == "LPO_INVESTOR")
                {
                    using (var httpClient = new HttpClient())
                    {
                        var data = new Dictionary<string, string>
                    {
                       { "FIRSTNAME", signup.FIRSTNAME },
                       { "SURNAME", signup.LASTNAME },
                       { "MIDDLENAME", signup.MIDDLENAME},
                       { "BIRTHDATE", signup.BIRTHDATE.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "STREET1", signup.STREET1 },
                       { "STREET2", signup.STREET2 },
                       { "MOBILENUMBER", signup.MOBILENUMBER },
                       { "LGA_ID", signup.lga },
                       { "STATE_ID", signup.state },
                       { "COUNTRY_ID", signup.country },
                       { "MARITAL_STATUS", signup.MaritalStatus },
                       { "MACADDRESS", "AAAAAA" },
                       { "EMAILADDRESS", signup.EMAILADDRESS},
                       { "PASSWORD", signup.PASSWORD },
                       { "CONFIRMPASSWORD", signup.PASSWORD },
                       { "CUSTOMER_CLASSIFICATION", "HIGH" },
                       { "TOKEN", "1111" },
                       { "LOGINCOUNT", "0" },
                       { "STATUS", "I" },
                       { "COMPANY_NAME", signup.COMPANY_NAME },
                       { "COMPANY_REG_NO", signup.COMPANY_REG_NO },
                       { "DATE_REG_WITH_ISSUER",  DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) },
                       { "NKEY", "1423232" },
                       { "CHANNEL", "W" }
                    };

                        var content = new FormUrlEncodedContent(data);


                        Response responsedes = new();
                        using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/EthSol_Investor", content))
                        {

                            string apiResponse = await response.Content.ReadAsStringAsync();

                            responsedes = JsonConvert.DeserializeObject<Response>(apiResponse);
                            responsedes.UserType = signup.UserType;

                            var convertedJson = JsonConvert.SerializeObject(responsedes);
                            TempData[FinanceUtility.Success] = "Sign Up Successfully";
                            TempData["tokenRev"] = convertedJson;
                        }


                    }
                }

                return RedirectToAction(nameof(ValidateProfile), "Home");
            }
            return View("SignUp2",signup);
        }

        public IActionResult ValidateProfile()
        {
            if (TempData["tokenRev"] is string s)
            {
                var responseUser = JsonConvert.DeserializeObject<Response>(s);
                // use newUser object now as needed
                return View(responseUser);
            }
            return View();
        }

        public async Task<IActionResult> SubmitToken(Response value)
        {
            Console.WriteLine(value);
            string nkey = GetIPAddress(value.EMAILADDRESS, value.UserType);
            using (var httpClient = new HttpClient())
            {
                var data = new Dictionary<string, string>
                {
                   
                   { "TYPE_OF_ACTOR", value.UserType},
                   { "ID", value.ID },
                   { "TOKEN", value.Token },
                   { "NKEY", nkey },//1234GGGADFF
                   { "CHANNEL", "W" }
                };
                var content = new FormUrlEncodedContent(data);

                CountryData countrydata = new CountryData();
                Response responsedes = new();
                using (var response = await httpClient.PostAsync("https://ethicalsol.uc.r.appspot.com/EthSol_Validate_Profile", content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();

                    responsedes = JsonConvert.DeserializeObject<Response>(apiResponse);
                    //List<SelectListItem> lstselectListItem = new List<SelectListItem>();
                    TempData[FinanceUtility.Success] = "You have validated successfully";

                }
                return RedirectToAction(nameof(Index));
            }
            //
        }

        public string GetIPAddress(string Email,string UserType)
        {
            //var BorrowersessionInfo = JsonConvert.DeserializeObject<ObjectSession>(HttpContext.Session.GetString("borrowersession"));
            //var Email = BorrowersessionInfo.Email;

            IPAddress remoteIpAddress = Request.HttpContext.Connection.RemoteIpAddress;
            string result = "";
            string result2 = "";
            if (remoteIpAddress != null)
            {
                // If we got an IPV6 address, then we need to ask the network for the IPV4 address 
                // This usually only happens when the browser is on the same machine as the server.
                if (remoteIpAddress.AddressFamily == System.Net.Sockets.AddressFamily.InterNetworkV6)
                {
                    remoteIpAddress = System.Net.Dns.GetHostEntry(remoteIpAddress).AddressList.First(x => x.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork);
                }
                result = remoteIpAddress.ToString();
            }
            var nkeyresult = HttpContext.Session.GetString("nkey");
            string MachineName1 = Environment.MachineName;
            //result2 = Email + " " + "LPO_BORROWER" + " " + MachineName1 + " " + result + " " + nkeyresult;
            result2 = Email + " " + UserType + " " + MachineName1 + " " + result + " " + nkeyresult;
            return result2;
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
