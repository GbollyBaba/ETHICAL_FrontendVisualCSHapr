﻿using EthicalVendor.Models;
using Microsoft.AspNetCore.Mvc;

namespace EthicalVendor.ViewComponents
{
    public class PersonalViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke(PersonalInfoModel personalinfo)
        {
            return View(personalinfo);
        }
    }
}

